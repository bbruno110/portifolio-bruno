/** Visual presets authored for this package; they are not React Bits presets. */
export const PRESETS = {
  silver: { colors: ['#6E6E80', '#FFFFFF'], backgroundColor: '#0a0a0a' },
  ocean: { colors: ['#197F9C', '#B9F8FF'], backgroundColor: '#030D18' },
  emerald: { colors: ['#2D8A68', '#C5FFDF'], backgroundColor: '#040E0B' },
  sunset: { colors: ['#B65A73', '#FFD8A4'], backgroundColor: '#150B14' },
  ink: { colors: ['#777789', '#171724'], backgroundColor: '#F3F0E9' },
} as const satisfies Record<string, { colors: readonly [string, string]; backgroundColor: string }>;

export type TidePreset = keyof typeof PRESETS | 'Silver' | 'Ocean' | 'Emerald' | 'Sunset' | 'Ink';

export interface TideOptions {
  preset?: TidePreset;
  colors?: readonly [string, string];
  /** Alias for colors[0]. Takes precedence over colors. */
  waterColor?: string;
  /** Alias for colors[1]. Takes precedence over colors. */
  crestColor?: string;
  backgroundColor?: string;
  density?: number;
  particleSize?: number;
  waveHeight?: number;
  choppiness?: number;
  wavelength?: number;
  windAngle?: number;
  horizon?: number;
  fog?: number;
  glow?: number;
  foam?: number;
  speed?: number;
  interactive?: boolean;
  parallax?: number;
  swell?: number;
  swellRadius?: number;
  clickRipples?: boolean;
  seed?: number;
  paused?: boolean;
  dpr?: number;
  /** Defaults to true: freeze when the OS requests reduced motion. */
  respectReducedMotion?: boolean;
  /** Match the particle budget to CSS area/device class. Default true. */
  adaptiveQuality?: boolean;
  /** Maximum GPU redraws per second. Default 30. */
  maxFps?: number;
  /** Window tracks passive backgrounds behind other page content. Default container. */
  eventSource?: 'container' | 'window';
}

export interface ResolvedOptions {
  colors: readonly [string, string];
  backgroundColor: string;
  density: number; particleSize: number; waveHeight: number; choppiness: number;
  wavelength: number; windAngle: number; horizon: number; fog: number;
  glow: number; foam: number; speed: number; interactive: boolean;
  parallax: number; swell: number; swellRadius: number; clickRipples: boolean;
  seed: number; paused: boolean; dpr: number; respectReducedMotion: boolean;
  adaptiveQuality: boolean; maxFps: number;
  eventSource: 'container' | 'window';
}

export const DEFAULT_OPTIONS: Readonly<ResolvedOptions> = Object.freeze({
  colors: ['#6E6E80', '#FFFFFF'] as const, backgroundColor: '#0a0a0a',
  density: 1, particleSize: 1, waveHeight: 1, choppiness: 0.8, wavelength: 1,
  windAngle: 0, horizon: 0.1, fog: 1, glow: 0.35, foam: 1, speed: 1,
  interactive: true, parallax: 1, swell: 1, swellRadius: 0.9,
  clickRipples: true, seed: 0, paused: false, dpr: 1.5, respectReducedMotion: true,
  adaptiveQuality: true, maxFps: 30,
  eventSource: 'container',
});

const clamp = (n: number | undefined, fallback: number, min: number, max: number) =>
  Number.isFinite(n) ? Math.min(max, Math.max(min, n!)) : fallback;

/** Resolve from complete props each time; removing a prop restores its default. */
export function resolveOptions(input: TideOptions = {}): ResolvedOptions {
  const key = input.preset?.toLowerCase() as keyof typeof PRESETS | undefined;
  const preset = key && Object.prototype.hasOwnProperty.call(PRESETS, key) ? PRESETS[key] : PRESETS.silver;
  const d = DEFAULT_OPTIONS;
  return {
    colors: [input.waterColor ?? input.colors?.[0] ?? preset.colors[0],
      input.crestColor ?? input.colors?.[1] ?? preset.colors[1]],
    backgroundColor: input.backgroundColor ?? preset.backgroundColor,
    density: clamp(input.density, d.density, 0.3, 2),
    particleSize: clamp(input.particleSize, d.particleSize, 0, 6),
    waveHeight: clamp(input.waveHeight, d.waveHeight, 0, 3),
    choppiness: clamp(input.choppiness, d.choppiness, 0, 3),
    wavelength: clamp(input.wavelength, d.wavelength, 0.15, 5),
    windAngle: Number.isFinite(input.windAngle) ? input.windAngle! % 360 : d.windAngle,
    horizon: clamp(input.horizon, d.horizon, 0, 0.8),
    fog: clamp(input.fog, d.fog, 0, 4),
    glow: clamp(input.glow, d.glow, 0, 2),
    foam: clamp(input.foam, d.foam, 0, 4),
    speed: clamp(input.speed, d.speed, 0, 5),
    interactive: input.interactive ?? d.interactive,
    parallax: clamp(input.parallax, d.parallax, 0, 3),
    swell: clamp(input.swell, d.swell, 0, 3),
    swellRadius: clamp(input.swellRadius, d.swellRadius, 0.1, 5),
    clickRipples: input.clickRipples ?? d.clickRipples,
    seed: Number.isFinite(input.seed) ? input.seed! % 100000 : d.seed,
    paused: input.paused ?? d.paused,
    dpr: clamp(input.dpr, d.dpr, 0.5, 3),
    respectReducedMotion: input.respectReducedMotion ?? d.respectReducedMotion,
    adaptiveQuality: input.adaptiveQuality ?? d.adaptiveQuality,
    maxFps: clamp(input.maxFps, d.maxFps, 15, 60),
    eventSource: input.eventSource === 'window' ? 'window' : 'container',
  };
}
