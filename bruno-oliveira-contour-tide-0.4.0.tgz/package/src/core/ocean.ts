import type { ResolvedOptions } from './options';

/** Broad spectrum: long swells through short wind-driven ripples. */
const BANDS = [
  [13.8, 0.500, 0.12, 4.20], [10.8, 0.350, -0.50, 5.10],
  [7.5, 0.180, 0.85, 4.23], [4.8, 0.070, -0.90, 0.83],
  [2.8, 0.025, 1.10, 2.72], [1.6, 0.008, -0.75, 5.17],
  [0.93, 0.003, -1.04, 1.38], [0.48, 0.0015, 1.18, 3.49],
] as const;
export const WAVE_COUNT = BANDS.length;
export const CAMERA_HEIGHT = 3.7;
export const FOCAL_LENGTH = 1.65;
export const NEAR_DEPTH = 1.5;
export const FAR_DEPTH = 85;

export interface OceanWave {
  kx: number; kz: number; k: number; amplitude: number; omega: number; phase: number;
  horizontal: number;
}
export interface OceanSpectrum { waves: OceanWave[]; steepness: number; amplitude: number }

/** Deep-water dispersion omega² = g k, with an artistic time scale. */
export function createOceanSpectrum(options: ResolvedOptions): OceanSpectrum {
  const wind = options.windAngle * Math.PI / 180;
  const waves = BANDS.map(([length, amplitude, direction, phase], i) => {
    const k = 2 * Math.PI / (length * options.wavelength);
    const angle = wind + direction;
    return { k, kx: Math.sin(angle) * k, kz: -Math.cos(angle) * k,
      amplitude: amplitude * options.waveHeight * 0.72, omega: Math.sqrt(9.81 * k) * 0.6,
      phase: (phase + options.seed * (i + 1) * 1.61803398875) % (2 * Math.PI), horizontal: 0 };
  });
  const amplitude = waves.reduce((sum, w) => sum + w.amplitude, 0);
  // Allocate a bounded compression budget across scales. Long swells get
  // coherent orbital compression rather than giving short ripples equal steepness.
  const steepness = Math.min(0.90, options.choppiness * 1.05) * Math.min(1, options.waveHeight);
  for (const wave of waves) wave.horizontal = amplitude > 0
    ? steepness * (wave.amplitude / amplitude) / wave.k : 0;
  return { waves, amplitude, steepness };
}

/** CPU reference for physical tests; never called in the particle render loop. */
export function sampleOcean(spectrum: OceanSpectrum, x: number, z: number, time: number) {
  const p = [x, 0, z]; const tx = [1, 0, 0]; const tz = [0, 0, 1];
  for (const w of spectrum.waves) {
    const phase = w.kx * x + w.kz * z - w.omega * time + w.phase;
    const c = Math.cos(phase), s = Math.sin(phase);
    const dx = w.kx / w.k, dz = w.kz / w.k;
    const h = w.horizontal;
    p[0] -= h * dx * s; p[1] += w.amplitude * c; p[2] -= h * dz * s;
    tx[0] -= h * dx * w.kx * c; tx[1] -= w.amplitude * w.kx * s;
    tx[2] -= h * dz * w.kx * c;
    tz[0] -= h * dx * w.kz * c; tz[1] -= w.amplitude * w.kz * s;
    tz[2] -= h * dz * w.kz * c;
  }
  return { position: p, tangentX: tx, tangentZ: tz,
    jacobian: tx[0] * tz[2] - tx[2] * tz[0] };
}

/** CSS area, not DPR: high-resolution phones do not multiply GPU work. */
export function particleCount(options: ResolvedOptions, width: number, height: number): number {
  if (width <= 0 || height <= 0) return 0;
  const budget = options.adaptiveQuality
    ? Math.min(width < 768 ? 100000 : 340000, Math.max(2000, Math.round(width * height * 0.75)))
    : 340000;
  return Math.round(budget * options.density);
}

/** Only eight phase updates per frame; particles are evaluated on the GPU. */
export function packOceanWaves(spectrum: OceanSpectrum, time: number, out: Float32Array): void {
  for (let i = 0; i < spectrum.waves.length; i++) {
    const w = spectrum.waves[i];
    out[i * 4] = w.kx; out[i * 4 + 1] = w.kz; out[i * 4 + 2] = w.amplitude;
    out[i * 4 + 3] = (w.phase - w.omega * time) % (2 * Math.PI);
  }
}

export function packOceanDirections(spectrum: OceanSpectrum, out: Float32Array): void {
  for (let i = 0; i < spectrum.waves.length; i++) {
    out[i * 2] = spectrum.waves[i].kx / spectrum.waves[i].k;
    out[i * 2 + 1] = spectrum.waves[i].kz / spectrum.waves[i].k;
  }
}

export function packOceanOrbits(spectrum: OceanSpectrum, out: Float32Array): void {
  for (let i = 0; i < spectrum.waves.length; i++) out[i] = spectrum.waves[i].horizontal;
}
