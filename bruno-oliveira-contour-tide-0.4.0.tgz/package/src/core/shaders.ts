import { CAMERA_HEIGHT, FOCAL_LENGTH, NEAR_DEPTH, FAR_DEPTH, WAVE_COUNT } from './ocean';

/** Shared continuous ocean equation, also compiled by GPU validation. */
export const oceanShader: string = /* glsl */ `
uniform vec4 uWaves[${WAVE_COUNT}];
uniform vec2 uDirections[${WAVE_COUNT}];
uniform float uOrbits[${WAVE_COUNT}];
void oceanSurface(vec2 anchor, out vec3 p, out vec3 tx, out vec3 tz) {
  p = vec3(anchor.x, 0.0, anchor.y);
  tx = vec3(1.0, 0.0, 0.0); tz = vec3(0.0, 0.0, 1.0);
  for (int i = 0; i < ${WAVE_COUNT}; i++) {
    vec4 w = uWaves[i];
    vec2 dir = uDirections[i];
    float phase = dot(w.xy, anchor) + w.w;
    float c = cos(phase), s = sin(phase);
    float horizontal = uOrbits[i];
    p.xz -= horizontal * dir * s;
    p.y += w.z * c;
    tx += vec3(-horizontal * dir.x * w.x * c, -w.z * w.x * s, -horizontal * dir.y * w.x * c);
    tz += vec3(-horizontal * dir.x * w.y * c, -w.z * w.y * s, -horizontal * dir.y * w.y * c);
  }
}
`;

export const vertexShader: string = /* glsl */ `
precision highp float;
attribute vec3 aParticle;
uniform float uTime, uAspect, uDpr, uDensity, uParticleSize, uDomainPadding;
uniform float uHorizon, uFog, uFoam, uParallax, uSwell, uSwellRadius, uAmplitude;
uniform vec3 uPointer;
uniform vec4 uRipples[8];
varying float vFoam, vAlpha, vShade, vReflection;
${oceanShader}
void main() {
  float depth = ${NEAR_DEPTH.toFixed(1)} * pow(${(FAR_DEPTH / NEAR_DEPTH).toFixed(5)}, aParticle.y);
  float x = (aParticle.x * 2.0 - 1.0) * (depth * uAspect / ${FOCAL_LENGTH} + uDomainPadding);
  vec2 anchor = vec2(x, depth);
  vec3 p, tx, tz;
  oceanSurface(anchor, p, tx, tz);
  if (uSwell > 0.0 && uPointer.z > 0.001) {
    vec2 offset = p.xz - uPointer.xy;
    float sigma2 = uSwellRadius * uSwellRadius;
    float lift = exp(-dot(offset, offset) / (2.0 * sigma2)) * uSwell * uPointer.z * 0.45;
    p.y += lift;
    tx.y -= lift * offset.x / sigma2; tz.y -= lift * offset.y / sigma2;
  }
  float rippleLight = 0.0;
  for (int i = 0; i < 8; i++) {
    if (uRipples[i].w > 0.0) {
      float age = max(0.0, uTime - uRipples[i].z);
      vec2 r = p.xz - uRipples[i].xy;
      float distance = length(r);
      float delta = distance - age * 3.0;
      float ring = exp(-delta * delta * 1.8 - age * 0.65) * uRipples[i].w;
      float s = sin(delta * 4.0), c = cos(delta * 4.0);
      p.y += ring * s * 0.2;
      vec2 gradient = r / max(distance, 0.001) * ring * (4.0 * c - 3.6 * delta * s) * 0.2;
      tx.y += gradient.x; tz.y += gradient.y;
      rippleLight += ring * 0.6;
    }
  }
  vec3 normal = normalize(cross(tz, tx));
  vec3 view = normalize(vec3(-p.x, ${CAMERA_HEIGHT} - p.y, -p.z));
  vec3 light = normalize(vec3(-0.18, 0.55, 0.82));
  vec3 halfway = normalize(view + light);
  float glint = pow(max(0.0, dot(normal, halfway)), 90.0);
  float fresnel = pow(1.0 - max(0.0, dot(normal, view)), 3.0);
  float jacobian = tx.x * tz.z - tx.z * tz.x;
  float compression = max(0.0, 1.0 - jacobian);
  float crest = smoothstep(-0.35, 0.60, p.y / max(0.01, uAmplitude));
  float fold = smoothstep(0.34, 0.70, compression);
  float whitecap = fold * fold;
  whitecap *= crest;
  vFoam = clamp((whitecap * 1.4 + rippleLight) * uFoam, 0.0, 1.0);
  vReflection = clamp(glint * (0.06 + fresnel * 0.25), 0.0, 0.3);
  vShade = 0.34 + max(0.0, dot(normal, light)) * 0.16 + crest * 0.08;
  vAlpha = exp(-max(p.z - 6.0, 0.0) * 0.012 * uFog) * (0.4 + aParticle.z * 0.6);
  vAlpha *= 1.0 - smoothstep(${(FAR_DEPTH * 0.55).toFixed(1)}, ${FAR_DEPTH.toFixed(1)}, depth);
  vAlpha *= step(0.001, uParticleSize);
  float drift = clamp(uPointer.x, -12.0, 12.0) * uParallax * 0.035 * uPointer.z;
  float rise = clamp(uPointer.y - 12.0, -10.0, 20.0) * uParallax * 0.0023 * uPointer.z;
  float horizon = 1.0 - uHorizon * 2.0;
  gl_Position = vec4((p.x - drift) * ${FOCAL_LENGTH} / uAspect,
    (horizon + rise) * p.z - (${CAMERA_HEIGHT} - p.y) * ${FOCAL_LENGTH}, p.z - 0.4, p.z);
  gl_PointSize = clamp(uParticleSize * uDpr * (0.65 + 1.5 / sqrt(depth)) *
    clamp(sqrt(1.0 / uDensity), 0.8, 1.35), 1.0, 28.0);
}
`;

export const fragmentShader: string = /* glsl */ `
precision mediump float;
uniform vec3 uWater, uCrest;
uniform float uGlow;
varying float vFoam, vAlpha, vShade, vReflection;
void main() {
  float r = length(gl_PointCoord - 0.5) * 2.0;
  if (r > 1.0) discard;
  float core = 1.0 - smoothstep(0.15, 0.85, r);
  float halo = (1.0 - r) * (1.0 - r) * uGlow;
  float light = clamp(vFoam * 0.7 + vReflection * 0.9, 0.0, 1.0);
  float alpha = clamp((core * 0.88 + halo * 0.35) * vAlpha * (0.65 + light * 1.4), 0.0, 1.0);
  if (alpha < 0.006) discard;
  vec3 color = mix(uWater * vShade, uCrest, light);
  gl_FragColor = vec4(color * alpha, alpha);
}
`;
