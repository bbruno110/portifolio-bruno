import { resolveOptions, type TideOptions, type ResolvedOptions } from './options';
import { fragmentShader, vertexShader } from './shaders';
import { createOceanSpectrum, packOceanWaves, packOceanDirections, packOceanOrbits, particleCount, WAVE_COUNT,
  CAMERA_HEIGHT, FOCAL_LENGTH, NEAR_DEPTH, FAR_DEPTH } from './ocean';

export interface TideRenderer {
  setOptions(options: TideOptions): void;
  destroy(): void;
}
export interface RendererCallbacks {
  onError?: (error: Error) => void;
}

/** Deterministic anchors. Default budget here is 340k; renderer supplies its adaptive budget. */
export function createParticleField(density: number, seed: number, budget = 340000): Float32Array {
  const count = Math.round(budget * density);
  const columns = Math.ceil(Math.sqrt(count * 1.7));
  const rows = Math.ceil(count / columns);
  const data = new Float32Array(count * 3);
  let state = (Math.floor(seed * 1009) ^ 0x9e3779b9) >>> 0;
  const random = () => {
    state ^= state << 13; state ^= state >>> 17; state ^= state << 5;
    return (state >>> 0) / 4294967296;
  };
  for (let i = 0; i < count; i++) {
    data[i * 3] = ((i % columns) + random()) / columns;
    data[i * 3 + 1] = (Math.floor(i / columns) + random()) / rows;
    data[i * 3 + 2] = random();
  }
  return data;
}

export function createTide(
  canvas: HTMLCanvasElement,
  initial: TideOptions = {},
  callbacks: RendererCallbacks = {},
): TideRenderer {
  const root = canvas.parentElement;
  if (!root) throw new Error('ContourTide: the canvas must be attached to a container.');
  const context = canvas.getContext('webgl', {
    alpha: true, antialias: false, premultipliedAlpha: true,
    depth: false, stencil: false, powerPreference: 'low-power',
  });
  if (!context) throw new Error('ContourTide: WebGL is unavailable on this device.');
  const gl = context;
  let options = resolveOptions(initial);
  let spectrum = createOceanSpectrum(options);
  const waveData = new Float32Array(WAVE_COUNT * 4);
  const directionData = new Float32Array(WAVE_COUNT * 2);
  const orbitData = new Float32Array(WAVE_COUNT);
  let program: WebGLProgram | null = null;
  let buffer: WebGLBuffer | null = null;
  let uniforms: Record<string, WebGLUniformLocation | null> = {};
  let count = 0;
  let frame = 0;
  let previousTime = 0;
  let lastDraw = 0;
  let uniformsDirty = true;
  let time = 0;
  let destroyed = false;
  let contextLost = false;
  let intersecting = true;
  const initialRect = root.getBoundingClientRect();
  let width = initialRect.width, height = initialRect.height;
  let background: [number, number, number, number] = [0, 0, 0, 1];
  let water: number[] = [], crest: number[] = [];
  let additive = false;
  const pointer = new Float32Array([0, 12, 0]);
  const target = new Float32Array([0, 12, 0]);
  const ripples = new Float32Array(8 * 4);
  let nextRipple = 0;
  // Canvas2D parses CSS colors consistently without injecting them into markup.
  const parser = document.createElement('canvas').getContext('2d');
  const media = window.matchMedia('(prefers-reduced-motion: reduce)');
  const parseColor = (value: string): [number, number, number, number] => {
    if (!parser) return [0, 0, 0, 1];
    parser.clearRect(0, 0, 1, 1);
    parser.fillStyle = '#000000';
    parser.fillStyle = value;
    parser.fillRect(0, 0, 1, 1);
    const d = parser.getImageData(0, 0, 1, 1).data;
    return [d[0] / 255, d[1] / 255, d[2] / 255, d[3] / 255];
  };
  const refreshColors = () => {
    background = parseColor(options.backgroundColor);
    water = parseColor(options.colors[0]).slice(0, 3);
    crest = parseColor(options.colors[1]).slice(0, 3);
    const luminance = background[0] * 0.2126 + background[1] * 0.7152 + background[2] * 0.0722;
    additive = background[3] > 0.95 && luminance < 0.55;
    if (background[3] > 0 && luminance > 0.55) {
      // Convert bright crests to ink on a light background, preserving hue.
      const ink = (c: number) => 0.04 + (1 - c) * 0.3;
      water = water.map(ink); crest = crest.map(ink);
    }
  };
  const compile = (type: number, source: string) => {
    const shader = gl.createShader(type);
    if (!shader) throw new Error('ContourTide: could not allocate a shader.');
    gl.shaderSource(shader, source); gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const log = gl.getShaderInfoLog(shader); gl.deleteShader(shader);
      throw new Error(`ContourTide shader: ${log}`);
    }
    return shader;
  };
  const uploadField = () => {
    const total = particleCount(options, width, height);
    const field = createParticleField(options.density, options.seed, total / options.density);
    count = field.length / 3;
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, field, gl.STATIC_DRAW);
  };
  const initialize = () => {
    const vertex = compile(gl.VERTEX_SHADER, vertexShader);
    let fragment: WebGLShader;
    try { fragment = compile(gl.FRAGMENT_SHADER, fragmentShader); }
    catch (error) { gl.deleteShader(vertex); throw error; }
    program = gl.createProgram();
    if (!program) { gl.deleteShader(vertex); gl.deleteShader(fragment); throw new Error('ContourTide: program allocation failed.'); }
    gl.attachShader(program, vertex); gl.attachShader(program, fragment);
    gl.linkProgram(program); gl.deleteShader(vertex); gl.deleteShader(fragment);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      const log = gl.getProgramInfoLog(program); gl.deleteProgram(program); program = null;
      throw new Error(`ContourTide program: ${log}`);
    }
    gl.useProgram(program);
    buffer = gl.createBuffer();
    if (!buffer) { gl.deleteProgram(program); program = null; throw new Error('ContourTide: buffer allocation failed.'); }
    uploadField();
    const attribute = gl.getAttribLocation(program, 'aParticle');
    gl.enableVertexAttribArray(attribute);
    gl.vertexAttribPointer(attribute, 3, gl.FLOAT, false, 0, 0);
    uniforms = {};
    for (const name of ['Time', 'Aspect', 'Dpr', 'Density', 'ParticleSize', 'WaveHeight',
      'Choppiness', 'Wavelength', 'WindAngle', 'Horizon', 'Fog', 'Foam', 'Seed',
      'Parallax', 'Swell', 'SwellRadius', 'Pointer', 'Water', 'Crest', 'Glow', 'Amplitude', 'Steepness', 'DomainPadding']) {
      uniforms[name] = gl.getUniformLocation(program, `u${name}`);
    }
    uniforms.Ripples = gl.getUniformLocation(program, 'uRipples[0]');
    uniforms.Waves = gl.getUniformLocation(program, 'uWaves[0]');
    uniforms.Directions = gl.getUniformLocation(program, 'uDirections[0]');
    uniforms.Orbits = gl.getUniformLocation(program, 'uOrbits[0]');
    gl.disable(gl.DEPTH_TEST); gl.depthMask(false);
    gl.enable(gl.BLEND); uniformsDirty = true;
    // Standard alpha also supports dark ink and transparent backgrounds.
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  };
  const canAnimate = () => !options.paused && options.speed > 0 &&
    !(options.respectReducedMotion && media.matches);
  const visible = () => !document.hidden && intersecting && width > 0 && height > 0;
  const schedule = () => {
    if (!destroyed && !contextLost && !frame && visible()) frame = requestAnimationFrame(render);
  };
  function render(now: number) {
    frame = 0;
    if (destroyed || contextLost || !visible()) { previousTime = 0; return; }
    if (canAnimate() && lastDraw && now - lastDraw < 1000 / options.maxFps - 1) { schedule(); return; }
    lastDraw = now;
    const delta = previousTime ? Math.min((now - previousTime) / 1000, 0.12) : 0;
    previousTime = now;
    if (canAnimate()) {
      time += delta * options.speed;
      const smoothing = 1 - Math.exp(-delta * 5);
      for (let i = 0; i < 3; i++) pointer[i] += (target[i] - pointer[i]) * smoothing;
    }
    gl.useProgram(program);
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clearColor(background[0] * background[3], background[1] * background[3],
      background[2] * background[3], background[3]); gl.clear(gl.COLOR_BUFFER_BIT);
    if (uniformsDirty) {
      // Emissive points accumulate at projected crests instead of painting broad opaque faces.
      // Ink and transparent backgrounds keep ordinary alpha composition.
      gl.blendFunc(gl.ONE, additive ? gl.ONE : gl.ONE_MINUS_SRC_ALPHA);
      const floats: Record<string, number> = {
      Aspect: width / Math.max(1, height), Dpr: canvas.width / Math.max(1, width),
      Density: options.density, ParticleSize: options.particleSize,
      WaveHeight: options.waveHeight, Choppiness: options.choppiness,
      Wavelength: options.wavelength, WindAngle: options.windAngle,
      Horizon: options.horizon, Fog: options.fog, Foam: options.foam,
      Seed: options.seed, Parallax: options.interactive ? options.parallax : 0,
      Swell: options.interactive ? options.swell : 0,
      SwellRadius: options.swellRadius, Glow: options.glow,
      Amplitude: spectrum.amplitude, Steepness: spectrum.steepness,
      DomainPadding: spectrum.waves.reduce((sum, wave) => sum + wave.horizontal *
        (Math.abs(wave.kx / wave.k) + width / Math.max(1, height) / FOCAL_LENGTH * Math.abs(wave.kz / wave.k)), 0)
        + (options.interactive ? options.parallax * 0.5 : 0) + 0.2,
    };
    for (const key in floats) gl.uniform1f(uniforms[key], floats[key]);
      gl.uniform3fv(uniforms.Water, water); gl.uniform3fv(uniforms.Crest, crest);
      packOceanDirections(spectrum, directionData);
      gl.uniform2fv(uniforms.Directions, directionData);
      packOceanOrbits(spectrum, orbitData);
      gl.uniform1fv(uniforms.Orbits, orbitData);
      uniformsDirty = false;
    }
    packOceanWaves(spectrum, time, waveData);
    gl.uniform1f(uniforms.Time, time);
    gl.uniform4fv(uniforms.Waves, waveData);
    gl.uniform3fv(uniforms.Pointer, pointer);
    for (let i = 0; i < 8; i++) if (ripples[i * 4 + 3] && time - ripples[i * 4 + 2] > 10) ripples[i * 4 + 3] = 0;
    gl.uniform4fv(uniforms.Ripples, ripples);
    gl.drawArrays(gl.POINTS, 0, count);
    if (canAnimate()) schedule(); else previousTime = 0;
  }
  const resize = () => {
    const rect = root.getBoundingClientRect();
    width = rect.width; height = rect.height;
    const ratio = Math.min(window.devicePixelRatio || 1, options.dpr);
    const newWidth = Math.max(1, Math.round(width * ratio));
    const newHeight = Math.max(1, Math.round(height * ratio));
    if (canvas.width !== newWidth) canvas.width = newWidth;
    if (canvas.height !== newHeight) canvas.height = newHeight;
    if (!contextLost && count !== particleCount(options, width, height)) uploadField();
    uniformsDirty = true;
    schedule();
  };
  const position = (event: PointerEvent): [number, number] | null => {
    const rect = root.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0 || event.clientX < rect.left || event.clientX > rect.right ||
      event.clientY < rect.top || event.clientY > rect.bottom) return null;
    const nx = (event.clientX - rect.left) / Math.max(1, rect.width) * 2 - 1;
    const ny = 1 - (event.clientY - rect.top) / Math.max(1, rect.height) * 2;
    const depth = Math.min(FAR_DEPTH, Math.max(NEAR_DEPTH, CAMERA_HEIGHT * FOCAL_LENGTH /
      Math.max(0.06, 1 - options.horizon * 2 - ny)));
    return [nx * depth * width / Math.max(1, height) / FOCAL_LENGTH, depth];
  };
  const move = (event: PointerEvent) => {
    if (!options.interactive) return;
    const location = position(event);
    if (!location) { leave(); return; }
    const [x, z] = location; target.set([x, z, 1]); schedule();
  };
  const leave = () => { target[2] = 0; schedule(); };
  const up = (event: PointerEvent) => { if (event.pointerType !== 'mouse') leave(); };
  const down = (event: PointerEvent) => {
    move(event);
    if (!options.clickRipples || !canAnimate()) return;
    const location = position(event);
    if (!location) return;
    const [x, z] = location;
    ripples.set([x, z, time, 1], nextRipple * 4);
    nextRipple = (nextRipple + 1) % 8; schedule();
  };
  const visibilityChanged = () => {
    previousTime = 0; lastDraw = 0;
    if (!visible() && frame) { cancelAnimationFrame(frame); frame = 0; }
    schedule();
  };
  const lost = (event: Event) => {
    event.preventDefault(); contextLost = true;
    cancelAnimationFrame(frame); frame = 0; previousTime = 0;
  };
  const restored = () => {
    if (destroyed) return;
    try { initialize(); contextLost = false; previousTime = 0; resize(); }
    catch (error) { callbacks.onError?.(error instanceof Error ? error : new Error(String(error))); }
  };
  let eventTarget: Window | HTMLElement = options.eventSource === 'window' ? window : root;
  const bindInput = (attach: boolean) => {
    const target = eventTarget as EventTarget;
    const listeners = [['pointermove', move], ['pointerdown', down], ['pointerleave', leave],
      ['pointercancel', leave], ['pointerup', up]] as const;
    for (const [name, listener] of listeners) {
      if (attach) target.addEventListener(name, listener as EventListener, { passive: true });
      else target.removeEventListener(name, listener as EventListener);
    }
  };
  // Allocate before listeners so a failed initialization leaves no observers behind.
  initialize(); refreshColors();
  const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : null;
  observer?.observe(root);
  const intersection = typeof IntersectionObserver !== 'undefined' ? new IntersectionObserver(([entry]) => {
    intersecting = entry.isIntersecting; visibilityChanged();
  }) : null;
  intersection?.observe(root);
  window.addEventListener('resize', resize);
  document.addEventListener('visibilitychange', visibilityChanged);
  media.addEventListener('change', visibilityChanged);
  bindInput(true);
  window.addEventListener('blur', leave);
  canvas.addEventListener('webglcontextlost', lost);
  canvas.addEventListener('webglcontextrestored', restored);
  resize();
  return {
    setOptions(next: TideOptions) {
      if (destroyed) return;
      const before: ResolvedOptions = options;
      options = resolveOptions(next);
      if (before.eventSource !== options.eventSource) {
        bindInput(false); eventTarget = options.eventSource === 'window' ? window : root;
        pointer[2] = 0; target[2] = 0; bindInput(true);
      }
      spectrum = createOceanSpectrum(options);
      if (!options.interactive) { pointer[2] = 0; target[2] = 0; }
      if (!options.clickRipples) ripples.fill(0);
      if (before.density !== options.density || before.seed !== options.seed) {
        if (!contextLost) uploadField();
      }
      refreshColors(); previousTime = 0; lastDraw = 0; uniformsDirty = true; resize();
    },
    destroy() {
      if (destroyed) return;
      destroyed = true; cancelAnimationFrame(frame);
      observer?.disconnect(); intersection?.disconnect();
      window.removeEventListener('resize', resize);
      document.removeEventListener('visibilitychange', visibilityChanged);
      media.removeEventListener('change', visibilityChanged);
      bindInput(false);
      window.removeEventListener('blur', leave);
      canvas.removeEventListener('webglcontextlost', lost);
      canvas.removeEventListener('webglcontextrestored', restored);
      gl.deleteBuffer(buffer); gl.deleteProgram(program);
    },
  };
}
