import { createTide } from '../core/renderer';
import type { TideOptions } from '../core/options';

declare global {
  interface Window {
    ReactNativeWebView?: { postMessage(message: string): void };
    __TIDE_OPTIONS__?: TideOptions;
    __TIDE_UPDATE__?: (options: TideOptions) => void;
  }
}

const send = (message: unknown) => window.ReactNativeWebView?.postMessage(JSON.stringify(message));
try {
  const canvas = document.getElementById('tide') as HTMLCanvasElement;
  const renderer = createTide(canvas, window.__TIDE_OPTIONS__, {
    onError: (error) => send({ type: 'error', message: error.message }),
  });
  window.__TIDE_UPDATE__ = (options) => renderer.setOptions(options);
  window.addEventListener('pagehide', () => renderer.destroy(), { once: true });
  send({ type: 'ready' });
} catch (error) {
  send({ type: 'error', message: error instanceof Error ? error.message : String(error) });
}
