import { RUNTIME_SOURCE } from './runtime.generated';
import { resolveOptions, type TideOptions } from '../core/options';

/** Safe in an inline script and in injectJavaScript, even with user-provided color strings. */
export function serializeOptions(options: TideOptions): string {
  return JSON.stringify(resolveOptions(options)).replace(/</g, '\\u003c')
    .replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
}

export function createNativeDocument(options: TideOptions): string {
  return `<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'none'">
<style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:transparent}body{position:relative;touch-action:pan-y}canvas{position:absolute;inset:0;width:100%;height:100%;display:block}</style>
</head><body><canvas id="tide" aria-hidden="true"></canvas><script>window.__TIDE_OPTIONS__=${serializeOptions(options)};</script>
<script>${RUNTIME_SOURCE.replace(/<\/script/gi, '<\\/script')}</script></body></html>`;
}
