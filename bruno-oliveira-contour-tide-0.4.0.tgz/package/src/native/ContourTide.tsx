import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { AccessibilityInfo, AppState, StyleSheet, View, type StyleProp, type ViewStyle } from 'react-native';
import { WebView, type WebViewMessageEvent } from 'react-native-webview';
import { resolveOptions, type TideOptions } from '../core/options';
import { createNativeDocument, serializeOptions } from './html';

export interface ContourTideProps extends TideOptions {
  /** React Native styles (not CSSProperties). Give the root a height or flex: 1. */
  style?: StyleProp<ViewStyle>;
  /** Forwarded to View for integrations such as NativeWind. Core RN does not interpret it. */
  className?: string;
  children?: ReactNode;
  onError?: (error: Error) => void;
}

/** iOS/Android adapter. Same GPU engine, embedded locally inside react-native-webview. */
export function ContourTide({ style, className, children, onError, ...options }: ContourTideProps) {
  const view = useRef<WebView<unknown>>(null);
  const ready = useRef(false);
  const [active, setActive] = useState(AppState.currentState !== 'background' && AppState.currentState !== 'inactive');
  const [reducedMotion, setReducedMotion] = useState(false);
  const resolved = resolveOptions(options);
  const effective = { ...resolved, paused: resolved.paused || !active ||
    (resolved.respectReducedMotion && reducedMotion) };
  const serialized = serializeOptions(effective);
  const latest = useRef({ serialized, onError });
  latest.current = { serialized, onError };
  // This object never changes. Live updates use the bridge rather than reloading HTML.
  const [source] = useState(() => ({ html: createNativeDocument(effective), baseUrl: 'about:blank' }));

  useEffect(() => {
    let mounted = true;
    AccessibilityInfo.isReduceMotionEnabled()
      .then((value) => { if (mounted) setReducedMotion(value); })
      .catch(() => { /* The embedded browser still checks its own media query. */ });
    const motion = AccessibilityInfo.addEventListener('reduceMotionChanged', setReducedMotion);
    const app = AppState.addEventListener('change', (state) => setActive(state === 'active'));
    return () => { mounted = false; motion.remove(); app.remove(); };
  }, []);

  const pushOptions = useCallback(() => {
    if (ready.current) view.current?.injectJavaScript(
      `window.__TIDE_UPDATE__&&window.__TIDE_UPDATE__(${latest.current.serialized});true;`,
    );
  }, []);
  useEffect(pushOptions, [serialized, pushOptions]);
  const receive = useCallback((event: WebViewMessageEvent) => {
    let data: { type?: string; message?: string };
    try { data = JSON.parse(event.nativeEvent.data); } catch { return; }
    if (data.type === 'ready') { ready.current = true; pushOptions(); }
    if (data.type === 'error') {
      const error = new Error(data.message || 'ContourTide: WebView rendering failed.');
      if (latest.current.onError) latest.current.onError(error); else console.warn(error.message);
    }
  }, [pushOptions]);

  return <View {...(className ? { className } : {})} style={[styles.root, style,
    { backgroundColor: resolved.backgroundColor }]}>
    <WebView<unknown> ref={view} source={source} originWhitelist={['*']}
      style={styles.webview} containerStyle={styles.webviewContainer}
      javaScriptEnabled scrollEnabled={false} bounces={false}
      overScrollMode="never" androidLayerType="hardware" setSupportMultipleWindows={false}
      onMessage={receive} onLoadStart={() => { ready.current = false; }}
      onError={(event) => {
        const error = new Error(event.nativeEvent.description);
        if (latest.current.onError) latest.current.onError(error); else console.warn(error.message);
      }}
      onShouldStartLoadWithRequest={({ url }) => url === 'about:blank' || url.startsWith('data:text/html')}
      onContentProcessDidTerminate={() => { ready.current = false; view.current?.reload(); }}
      onRenderProcessGone={() => { ready.current = false; view.current?.reload(); }}
      accessible={false} />
    {children != null && <View pointerEvents="box-none" style={styles.content}>{children}</View>}
  </View>;
}

const styles = StyleSheet.create({
  root: { overflow: 'hidden' },
  webviewContainer: { ...StyleSheet.absoluteFillObject },
  webview: { flex: 1, backgroundColor: 'transparent' },
  content: { ...StyleSheet.absoluteFillObject },
});

export default ContourTide;
