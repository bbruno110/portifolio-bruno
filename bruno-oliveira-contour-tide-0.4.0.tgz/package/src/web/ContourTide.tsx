'use client';

import { useEffect, useRef, type CSSProperties, type ReactNode } from 'react';
import { createTide, type TideRenderer } from '../core/renderer';
import { resolveOptions, type TideOptions } from '../core/options';

export interface ContourTideProps extends TideOptions {
  className?: string;
  style?: CSSProperties;
  children?: ReactNode;
  onError?: (error: Error) => void;
}

/** SSR-safe wrapper. Only the effect touches the DOM/WebGL. */
export function ContourTide({ className, style, children, onError, ...options }: ContourTideProps) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const engine = useRef<TideRenderer | null>(null);
  const latest = useRef({ options, onError });
  latest.current = { options, onError };
  // Serializing the small normalized API avoids restarting the GPU on rerender.
  const resolved = resolveOptions(options);
  const signature = JSON.stringify(resolved);

  useEffect(() => {
    if (!canvas.current) return;
    const report = (error: Error) => {
      if (latest.current.onError) latest.current.onError(error);
      else console.warn(error.message);
    };
    try { engine.current = createTide(canvas.current, latest.current.options, { onError: report }); }
    catch (error) { report(error instanceof Error ? error : new Error(String(error))); }
    return () => { engine.current?.destroy(); engine.current = null; };
  }, []);

  useEffect(() => { engine.current?.setOptions(latest.current.options); }, [signature]);

  return (
    <div className={className} style={{ position: 'relative', width: '100%', aspectRatio: '16 / 9',
      overflow: 'hidden', isolation: 'isolate', ...style, backgroundColor: resolved.backgroundColor }}>
      <canvas ref={canvas} aria-hidden="true" style={{ position: 'absolute', inset: 0,
        width: '100%', height: '100%', display: 'block', pointerEvents: 'none' }} />
      {children != null && <div style={{ position: 'relative', zIndex: 1, height: '100%' }}>{children}</div>}
    </div>
  );
}

export default ContourTide;
