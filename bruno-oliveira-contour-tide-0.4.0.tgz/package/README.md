# Contour Tide 0.4 — Particle Ocean

Oceano de partículas em **React + TypeScript**, com renderização na GPU e adaptadores para **React web, Next.js, Vite e React Native (iOS/Android)**.

A versão 0.4 usa **8 componentes de Gerstner**, órbitas com compressão distribuída por escala, amostragem logarítmica em profundidade e composição aditiva dos pontos sobre fundos escuros. A revisão considera a gravação de aproximadamente 57 segundos enviada pelo solicitante, além das capturas anteriores. O visual prateado já vem pronto por padrão:

```tsx
import ContourTide from '@bruno-oliveira/contour-tide';

export default function Example() {
  return <ContourTide />;
}
```

Na web, sem estilo de tamanho, a área tem proporção responsiva 16:9. Você pode definir outra altura por CSS ou `style`. As props omitidas restauram os padrões. A versão já vem com **30 FPS de limite**, orçamento adaptativo de partículas e pausa quando o efeito não está visível. Leia [o modelo do oceano e o orçamento de renderização](docs/ocean-model.md) e [como atualizar do pacote anterior](CHANGELOG.md).

Implementação original inspirada na descrição e na API de [Contour Tide, do React Bits Pro](https://pro.reactbits.dev/docs/components/contour-tide). Não contém código, shaders, assets ou presets extraídos do produto original, não é afiliada a ele e não promete reprodução visual idêntica. A API fornecida, as capturas e a gravação do solicitante guiaram a implementação. O código deste repositório está sob licença MIT.

## Ver a animação antes de instalar

Abra **`preview.html`** do ZIP no Chrome/Edge/Firefox. É uma prévia local animada com o mesmo renderer, com interação e clique habilitados por padrão, sem depender de servidor, React ou conexão com a internet. Use **Configurar** para ajustar cores, ondas, densidade, interação e desempenho; **Copiar TSX** gera a configuração. Feche os controles para voltar à área inteira de oceano. A preferência de movimento reduzido do sistema também é respeitada nessa prévia.

## Rodar o projeto

Requisito de desenvolvimento: Node.js 20.19+ (ou 22.12+; CI usa Node 24).

```bash
npm ci
npm run dev
```

Abra `http://127.0.0.1:5173`. Para ver só o oceano padrão, sem texto nem controles, use `http://127.0.0.1:5173/?ocean`. O playground tem os controles da imagem, mais DPR, transparência, FPS, qualidade adaptativa e movimento reduzido. O botão de copiar gera o TSX com sua configuração. Nenhuma instalação de Three.js é necessária.

```bash
npm run build         # ESM, CommonJS, tipos e runtime local do mobile
npm run typecheck
npm test
npm run build:demo    # playground estático em demo-dist/
npx playwright install chromium
npm run test:browser  # requer build + build:demo
npm pack             # gera um .tgz instalável, sem publicar
```

`npm ci` também compila o pacote pelo script `prepare`. O arquivo `src/native/runtime.generated.ts` é gerado a partir do mesmo renderer usado na web; após mudar o core, execute o build antes de testar no mobile. Não o edite manualmente.

## Usar em outro projeto

O nome `@bruno-oliveira/contour-tide` é a identificação configurada neste projeto, **não um pacote já publicado no npm**. O ZIP já contém `bruno-oliveira-contour-tide-0.4.0.tgz`. Copie esse arquivo para a raiz do aplicativo, ao lado do `package.json`, e execute ali:

```bash
npm install ./bruno-oliveira-contour-tide-0.4.0.tgz
```

Ou, depois de subir o conteúdo deste diretório no seu GitHub:

```bash
npm install git+https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
```

O script `prepare` compila o código nas instalações pelo Git. Publique a pasta raiz deste pacote, incluindo `scripts/`, `src/`, `package.json` e `package-lock.json`. `node_modules`, capturas de teste e builds de demonstração são ignorados pelo Git. A pasta `dist/` é produzida pelo build e incluída no pacote npm.

## React / Vite

```tsx
import ContourTide from '@bruno-oliveira/contour-tide';

export default function Hero() {
  return (
    <ContourTide
      preset="silver"
      colors={['#6E6E80', '#FFFFFF']}
      backgroundColor="#0a0a0a"
      density={1}
      waveHeight={1}
      choppiness={0.8}
      clickRipples
      style={{ height: 520, borderRadius: 20 }}
    >
      <div style={{ padding: 40, color: '#fff' }}>
        <h1>Seu conteúdo sobre o oceano.</h1>
        <button>Continuar</button>
      </div>
    </ContourTide>
  );
}
```

Na web, a proporção padrão é 16:9. Para personalizar, use `style={{ height: 520 }}`, uma classe com altura, ou um pai com altura explícita e o componente com `height: '100%'`. O canvas é decorativo (`aria-hidden`) e o conteúdo continua acessível. O componente não injeta CSS global nem depende de Tailwind.

## Next.js

O bundle web preserva `"use client"`. O efeito só cria WebGL após a montagem; o HTML inicial com o conteúdo pode ser renderizado no servidor. Não é necessário desabilitar SSR com `dynamic`.

```tsx
// app/page.tsx — pode continuar sendo um Server Component
import ContourTide from '@bruno-oliveira/contour-tide';

export default function Page() {
  return (
    <ContourTide style={{ height: '100svh' }} preset="ocean">
      <h1 style={{ padding: 40, color: 'white' }}>Olá, mundo.</h1>
    </ContourTide>
  );
}
```

Para usar callbacks como `onError`, renderize o componente dentro de um arquivo com `"use client"`, pois funções não atravessam a fronteira Server → Client do Next. Um exemplo está em `examples/next/`.

```bash
# A partir da raiz, depois de compilar o pacote
cd examples/next
npm ci
npm run dev
```

## React Native / Expo

Na web, o canvas usa WebGL diretamente. No React Native, o adaptador usa **react-native-webview** para executar **o mesmo renderer**, com HTML/JS embutidos no pacote. Não carrega uma página externa, CDN ou servidor. Não é uma implementação com `expo-gl`/Skia ou views nativas para cada partícula.

```bash
# Expo: escolha a versão compatível com o seu SDK
npx expo install react-native-webview

# React Native sem Expo
npm install react-native-webview
npx pod-install
```

```tsx
import { Text, View } from 'react-native';
import ContourTide from '@bruno-oliveira/contour-tide/native';

export default function Screen() {
  return (
    <ContourTide
      preset="ocean"
      density={0.35}
      dpr={1}
      style={{ flex: 1 }}
      onError={(error) => console.warn(error.message)}
    >
      <View pointerEvents="box-none" style={{ flex: 1, padding: 28 }}>
        <Text style={{ color: 'white', fontSize: 32 }}>Sua próxima onda.</Text>
      </View>
    </ContourTide>
  );
}
```

- `style` recebe `StyleProp<ViewStyle>` no Native e `CSSProperties` na web. A altura/flex do pai também precisa estar definida.
- `children` recebe componentes nativos (`View`, `Text` etc.) no Native e elementos HTML na web.
- `className` na web aceita classes CSS. No Native é repassada ao `View`, para ferramentas configuradas como NativeWind; React Native puro não interpreta classes.
- Toque corresponde ao ponteiro; tocar cria círculos e arrastar move a interação. A influência sai ao soltar o toque. Views sobrepostas que capturam toques impedem que eles cheguem à WebView; use `pointerEvents="box-none"` ou `"none"` em conteúdo decorativo.
- Mudanças de props são enviadas pela ponte, sem recriar a WebView nem reiniciar o tempo. O aplicativo pausa a animação quando vai ao fundo e acompanha a preferência de movimento reduzido.
- O padrão adaptativo já limita o orçamento a 100 mil partículas em uma área com menos de 768 CSS pixels de largura (antes de aplicar `density`). Para um perfil ainda mais econômico, use `density={0.5}` e `dpr={1}`. Desempenho depende da GPU/WebView.
- Use o import `/native` em iOS/Android. Para Expo Web, use o import raiz; o resolver deve escolher a condição web. O export raiz também tem condição `react-native` para Metro. O import explícito `/native` torna a intenção clara, inclusive para TypeScript.

O código do adaptador é checado com os tipos reais de React Native/WebView. O runtime embutido é coberto por teste no Chromium; **o adaptador não foi executado em um aparelho ou emulador Android/iOS nesta entrega**. Valide transparência, toques, ciclo de vida e desempenho nos dispositivos de destino. Não há garantia específica para React Native Windows/macOS ou WebViews antigas.

## Props

As 24 props solicitadas estão disponíveis. Os valores numéricos inválidos (`NaN`, infinito) voltam ao padrão, e números fora dos limites são limitados à faixa da tabela.

| Prop | Tipo | Padrão | Comportamento / faixa |
| --- | --- | --- | --- |
| `colors` | `readonly [string, string]` | `['#6E6E80', '#FFFFFF']` | Água e cristas; aceita hex, rgb/rgba e nomes CSS na web. Prefira hex no Native. |
| `backgroundColor` | `string` | `'#0a0a0a'` | Fundo; `'transparent'` mostra o conteúdo atrás. Fundos claros convertem partículas em tinta escura. |
| `density` | `number` | `1` | `0.3–2`; multiplica o orçamento adaptativo. Com `adaptiveQuality={false}`, 1 = 340.000 partículas, 0.3 = 102.000 e 2 = 680.000. |
| `particleSize` | `number` | `1` | `0–6`; 0 oculta as partículas. |
| `waveHeight` | `number` | `1` | Altura das ondas, `0–3`. |
| `choppiness` | `number` | `0.8` | Cristas mais pontudas, `0–3`. |
| `wavelength` | `number` | `1` | Comprimento relativo das ondas, `0.15–5`. |
| `windAngle` | `number` | `0` | Graus; normalizado com módulo 360. 0 faz as frentes dominantes se aproximarem. |
| `horizon` | `number` | `0.1` | Altura projetada do horizonte a partir do topo, `0–0.8`. |
| `fog` | `number` | `1` | Atenuação com a distância, `0–4`. |
| `glow` | `number` | `0.35` | Halo dentro de cada ponto, `0–2`. Não é bloom de pós-processamento. |
| `foam` | `number` | `1` | Realce das cristas e círculos, `0–4`. |
| `speed` | `number` | `1` | `0–5`; 0 mantém o tempo atual. |
| `interactive` | `boolean` | `true` | Habilita elevação e deriva pelo ponteiro/toque; independente de `clickRipples`. |
| `parallax` | `number` | `1` | Intensidade de deriva da vista, `0–3`; 0 a desliga. |
| `swell` | `number` | `1` | Elevação sob o ponteiro, `0–3`; 0 a desliga. |
| `swellRadius` | `number` | `0.9` | Raio em unidades do mundo, `0.1–5`. |
| `clickRipples` | `boolean` | `true` | Cliques/toques criam círculos; os 8 mais recentes coexistem. |
| `seed` | `number` | `0` | Padrão determinístico; aceita números finitos, módulo 100.000. |
| `paused` | `boolean` | `false` | Congela o tempo e a interação. Alterar uma prop visual ainda redesenha o quadro. |
| `dpr` | `number` | `1.5` | Limite de pixel ratio, `0.5–3`; usa o menor entre o dispositivo e este valor. |
| `className` | `string` | — | Classes do elemento raiz; veja as diferenças do Native acima. |
| `style` | `CSSProperties` / `StyleProp<ViewStyle>` | — | Estilo da raiz. Web tem proporção 16:9 por padrão; Native precisa de altura/flex. Use `backgroundColor` como prop para controlar também o renderer. |
| `children` | `ReactNode` | — | Conteúdo sobreposto à animação. |

As opções visuais da imagem também são props, com estes nomes:

| Controle da imagem | Prop |
| --- | --- |
| Preset | `preset="silver"` |
| Background | `backgroundColor="#0a0a0a"` |
| Water | `waterColor="#6E6E80"` ou `colors[0]` |
| Crest | `crestColor="#FFFFFF"` ou `colors[1]` |
| Demais sliders e switches | As props correspondentes da tabela anterior |

Props adicionais:

| Prop | Tipo | Padrão | Observação |
| --- | --- | --- | --- |
| `preset` | `TidePreset` | `'silver'` | `'silver'`, `'ocean'`, `'emerald'`, `'sunset'`, `'ink'`; aceita também a inicial maiúscula. Presets próprios deste pacote. |
| `waterColor` | `string` | — | Alias com prioridade sobre `colors[0]`. |
| `crestColor` | `string` | — | Alias com prioridade sobre `colors[1]`. |
| `respectReducedMotion` | `boolean` | `true` | Congela se o sistema pede movimento reduzido. `false` permite movimento mesmo assim. |
| `adaptiveQuality` | `boolean` | `true` | Limita a quantidade de partículas pela área CSS e pela largura do componente. Não muda a física ou as cores. |
| `maxFps` | `number` | `30` | Limite de desenhos por segundo, `15–60`. Não aumenta a velocidade da água. |
| `eventSource` | `'container' \| 'window'` | `'container'` | `'window'` recebe eventos globais dentro dos limites do efeito, mesmo atrás do conteúdo. Não bloqueia links. |
| `onError` | `(error: Error) => void` | — | Erros de WebGL/WebView. Sem callback, emite aviso no console e mantém o fundo/conteúdo. |

Prioridade: **padrão → cores do preset → `colors` / `backgroundColor` explícitos → `waterColor` / `crestColor`**. Os presets mudam apenas cores e fundo, não todos os parâmetros físicos. Para voltar aos valores do preset, remova os overrides explícitos. Variáveis CSS (`var(--color)`) não são resolvidas pelo parser de cores do renderer; passe o valor real.

## Interação, parallax e cliques opcionais

As ondas continuam se propagando com todas as interações desligadas. Cada controle tem uma função:

| Configuração | Resultado |
| --- | --- |
| Props omitidas | Ondas, elevação sob o ponteiro, deriva da câmera e círculos ao clicar |
| `interactive={false} clickRipples={false}` | Somente oceano, sem reação ao mouse/toque |
| `parallax={0}` | Câmera fixa; elevação sob o ponteiro e cliques continuam ativos |
| `swell={0}` | Sem elevação local; parallax e cliques continuam ativos |
| `clickRipples={false}` | Sem anéis de clique; parallax e elevação continuam ativos |
| `interactive={false} clickRipples={true}` | Apenas anéis de clique como interação |

```tsx
// Apenas o oceano, mantendo a aparência padrão
<ContourTide interactive={false} clickRipples={false} />

// Fundo do site: escuta mouse/cliques sem interceptar os links sobrepostos
<ContourTide eventSource="window" parallax={1} clickRipples />

// Sem parallax nem cliques, mas com a elevação local
<ContourTide parallax={0} clickRipples={false} />
```

No portfólio, copie `examples/next/background.tsx` para `src/components/background.tsx`. O exemplo escuta `window` e aceita as opções: `<Background />` habilita as interações padrão; `<Background interactive={false} clickRipples={false} />` as desliga. O `body` deve ter `position: relative` e `isolation: isolate` (`relative isolate` no Tailwind), conforme seu layout atual.

No Native, `window` é a janela interna da WebView; não captura toques interceptados por views nativas sobrepostas. Para conteúdo decorativo sobre a WebView, mantenha os `pointerEvents` indicados no exemplo Native.

## Arquitetura e desempenho

```text
src/core/options.ts       API, presets e normalização
src/core/ocean.ts         Espectro, dispersão, orçamento e referência matemática
src/core/shaders.ts       Ondas, espuma e projeção GLSL
src/core/renderer.ts      WebGL, buffers, ponteiro, RAF e ciclo de vida
src/web/ContourTide.tsx   Adaptador React / SSR
src/native/ContourTide.tsx Adaptador React Native / WebView
src/native/bridge.ts      Runtime local e mensagens de atualização
scripts/build.mjs        Gera os bundles e o runtime embutido
playground/              Demo Vite com todos os controles
examples/                Integrações Next e Native
tests/                   Configuração, segurança do HTML e SSR
```

As partículas são enviadas uma vez a um buffer. Cada quadro desenhado usa um único `drawArrays(POINTS)`. O JavaScript atualiza 8 fases (128 bytes de dados), sem percorrer as partículas. A física e a iluminação são calculadas na GPU. Direções são normalizadas previamente, os uniforms estáticos só mudam com a configuração e as interações inativas pulam o cálculo de círculos/elevação.

Alterar `density`, `seed`, `adaptiveQuality` ou o tamanho que determina o orçamento pode reenviar o campo. As demais props atualizam uniforms/espectro. O renderer pausa fora da tela, em abas ocultas, em tamanho zero, com movimento reduzido, `paused` ou `speed={0}`. Ao voltar, mantém o tempo sem avançar de uma vez. Há limpeza de RAF, listeners, observers, buffers e programas, além de restauração após perda do contexto WebGL.

Com `adaptiveQuality=true`, o orçamento base é `min(limitePorLargura, max(2000, round(largura × altura × 0.75)))`: o limite é 100.000 se a largura do componente for menor que 768 CSS pixels, e 340.000 nas demais áreas. A contagem final é `round(orçamento × density)`. A área usa pixels CSS, sem multiplicar pelo DPR. Em tamanho zero não renderiza.

**Mudança em relação à 0.3:** o limite desktop volta de 240 mil para 340 mil para preservar a continuidade do campo de pontos. Isso aumenta o trabalho de vértices no desktop. Para um perfil mais econômico, use `density={0.6} dpr={1}` (até 204 mil em área desktop grande). O limite de 30 FPS e o teto mobile de 100 mil continuam. A 0.4 não cria buffer de profundidade e não faz pós-processamento.

| Perfil | Configuração | Resultado |
| --- | --- | --- |
| Padrão para site | Props visuais omitidas | Oceano prateado, até 30 desenhos/s, orçamento adaptativo |
| Mais econômico | `density={0.5} dpr={1}` | Metade das partículas e framebuffer com DPR limitado a 1 |
| Mais fluido | `maxFps={60}` | Permite até 60 desenhos/s; pode consumir mais GPU |
| Quantidade original fixa | `adaptiveQuality={false}` | `density={1}` usa 340 mil partículas, independente da área |

Não há Three.js, texturas, vídeos, pós-processamento de bloom ou chamadas de rede do efeito. React não atualiza estado a cada quadro. O bundle da demonstração inclui React/React DOM; ele não representa o custo isolado do pacote.

O bundle web é pequeno e mantém React externo. Os tamanhos da prévia e da demonstração incluem estruturas diferentes e não representam consumo de GPU. O orçamento adaptativo e o limite de FPS continuam independentes das opções de interação.

Nos fundos escuros e opacos, os pontos acumulam luz para evidenciar regiões projetadas de maior concentração. Fundos claros e transparentes usam composição alfa normal para permitir tinta escura e integração com a página. Não há teste/escrita de profundidade dos pontos; a representação é uma superfície de partículas translúcidas.

WebGL tem diferenças entre GPUs. Centenas de milhares de partículas e DPR alto podem pesar; os limites são proteções de configuração, não uma promessa de FPS. Círculos e o levantamento do ponteiro usam a interseção aproximada com o plano da água. Transparência não deduz a cor da página: para partículas escuras em um fundo externo claro, escolha cores escuras explicitamente.

## Validação

- Testes de opções/presets, limites, campo determinístico, SSR sem DOM e serialização segura do HTML.
- Testes de dispersão, órbitas das partículas, tangentes por diferenças finitas, superfície sem dobramento, orçamento adaptativo e tamanho constante dos dados enviados por quadro.
- Entradas ESM/CommonJS verificadas sem DOM; bundle com fronteira `use client` preservada; exemplo Next com build de produção e pré-renderização.
- Teste de navegador para compilar os shaders, contar partículas reais no draw call, verificar updates sem realocar o campo, pausa, velocidade zero, movimento reduzido, resize, layout mobile, oceano sem props visuais e limite padrão de FPS. Usa Chromium com renderização por software; não é um benchmark de GPU de celular.
- Teste com conteúdo HTML sobreposto: eventos globais chegam ao fundo, parallax/elevação podem ser zerados e cliques podem ser habilitados/desabilitados independentemente.
- `npm run review:ocean` gera cinco quadros determinísticos do renderer real para revisão visual ao longo do movimento. As capturas ficam em `artifacts/` e não entram no pacote.
- Teste do HTML usado no Native: handshake, mudança de props pela ponte e recuperação do contexto WebGL. Não substitui teste em aparelho.
- CI em `.github/workflows/ci.yml` para rodar os checks a cada push/PR.

## Referências técnicas

- [React: useEffect e renderização no servidor](https://react.dev/reference/react/useEffect)
- [React: fronteira use client](https://react.dev/reference/rsc/use-client)
- [React Native WebView: guia e comunicação](https://github.com/react-native-webview/react-native-webview/blob/master/docs/Guide.md)
- [React Native WebView: API](https://github.com/react-native-webview/react-native-webview/blob/master/docs/Reference.md)
- [NVIDIA GPU Gems: Effective Water Simulation from Physical Models](https://developer.nvidia.com/gpugems/gpugems/part-i-natural-effects/chapter-1-effective-water-simulation-physical-models)
