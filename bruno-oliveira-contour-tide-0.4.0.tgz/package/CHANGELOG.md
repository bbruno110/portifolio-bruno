# Changelog

## 0.4.0

- Recalibra frequências e amplitudes a partir do trecho prateado da gravação longa, separando as ondas de base das mudanças de cor/densidade e da interação do mouse mostradas depois.
- Distribui a compressão lateral entre componentes por escala, com orçamento limitado a 0.90, em vez de aplicar o mesmo fator a todas as ondas. A superfície mantém órbitas contínuas e Jacobiano positivo.
- Usa profundidade logarítmica em um domínio mais próximo, com margem lateral calculada pelas órbitas e pelo parallax. Isso preenche o primeiro plano e evita bordas diagonais descobertas quando a água se desloca.
- Usa acúmulo aditivo de luz em fundo escuro opaco. Retira o buffer e o teste de profundidade dos pontos. Tinta em fundo claro e transparência mantêm composição alfa normal.
- Restabelece o orçamento desktop de até 340 mil partículas com density=1 para preservar detalhe. Mantém teto de 100 mil em áreas menores que 768 CSS pixels e limite padrão de 30 FPS. Para reduzir custo no desktop, use density=0.6 e dpr=1.
- A prévia offline tem controles e exportação TSX, além de reset. Não é preciso reinstalar o pacote para experimentar uma configuração.
- Mantém a API e os controles independentes de interação. A implementação é própria e não implica equivalência exata com o código original.

## 0.3.0

- Recalibra alturas, comprimentos, direções e câmera após comparação com o vídeo e as capturas do solicitante. Ondulações longas são combinadas com ondas menores que se cruzam; partículas do primeiro plano ficam menores e o brilho se concentra nas cristas.
- Troca a distribuição por profundidade inversa por uma distribuição estratificada em profundidade no mundo, preservando melhor as camadas distantes de água. Adiciona transição no limite distante do campo.
- Mantém o orçamento de partículas, o único draw call e o limite padrão de 30 FPS. Não adiciona simulação CPU por partícula ou texturas.
- Adiciona `eventSource="window"` para parallax/cliques em fundos passivos atrás do conteúdo, sem bloquear links. `interactive`, `parallax`, `swell` e `clickRipples` continuam opcionais e independentes conforme a documentação.
- Inclui `preview.html`: abra no navegador para testar a animação e os cliques antes de reinstalar no aplicativo.
- Adiciona revisão visual de cinco momentos do oceano e testes de interação através de conteúdo sobreposto.

## 0.2.0

- Substitui a deformação anterior por uma superfície oceânica de Gerstner com 8 bandas em várias direções e escalas.
- As partículas seguem órbitas horizontais e verticais; a compressão aproxima as partículas nas cristas. Espuma, normais e reflexos acompanham a superfície.
- Remove o realce de faixas artificiais por seno da altura.
- Mantém as 24 props, aliases e imports. Sem props visuais, a aparência padrão é prateada.
- Adiciona `maxFps`, padrão 30, e `adaptiveQuality`, padrão true, para uso em sites. `speed` continua controlando a velocidade da água, independentemente do teto de FPS.
- Adiciona tamanho responsivo 16:9 ao componente web sem altura definida. CSS e `style` podem definir outra altura.
- Mantém ESM/CommonJS, fronteira client do Next, adaptador Native com runtime local e testes de recuperação de contexto.

## Atualizar no seu projeto

1. Extraia o ZIP novo.
2. Copie **`bruno-oliveira-contour-tide-0.4.0.tgz`** para a raiz do seu aplicativo, ao lado do `package.json`.
3. No terminal do aplicativo:

```bash
npm install ./bruno-oliveira-contour-tide-0.4.0.tgz
```

4. Reinicie o servidor de desenvolvimento (`npm run dev`).
5. Em `Background`, remova os ajustes anteriores de cores, intensidade, espuma, opacidade e overlays. Use o exemplo atualizado `examples/next/background.tsx`, que escuta `window` para receber o mouse mesmo atrás do conteúdo. Se quer apenas o oceano sem interação, use `interactive={false} clickRipples={false}`.

O import permanece:

```tsx
import ContourTide from '@bruno-oliveira/contour-tide';
```

Para React Native, mantenha o sufixo `/native` e reinicie o Metro após a instalação. A instalação substitui a versão anterior; o pacote não foi publicado automaticamente no npm/GitHub.

### Mudança na interpretação de density

Na 0.1, `density={1}` sempre criava 340 mil partículas. Na 0.2/0.3, o modo adaptativo limitava a 240 mil em áreas largas e 100 mil em áreas menores que 768 CSS pixels. Na 0.4, o teto de áreas largas é 340 mil; áreas menores continuam com teto de 100 mil. A contagem acompanha também a área CSS e é multiplicada por `density`. Para uma quantidade fixa independentemente da área, use `adaptiveQuality={false}`.
