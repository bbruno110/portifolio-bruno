# Modelo do oceano e decisões de desempenho

Esta implementação produz um **oceano de partículas que acompanha ondas**, em uma superfície contínua. É uma aproximação procedural para renderização em tempo real, baseada em ondas de Gerstner e dispersão de água profunda. Não é um solver de Navier–Stokes/CFD, não usa FFT e não simula praia, colisões com objetos, spray ou espuma com conservação de massa. A aparência é uma implementação independente inspirada na referência visual fornecida.

## Como a água se move

Cada partícula tem uma posição de repouso fixa `q=(x,z)`. Não há sorteio por quadro ou reconstrução aleatória da superfície. Somamos oito componentes de comprimentos diferentes, com direções ao redor do vento. Para cada componente:

$$
k_i=2\pi/L_i,\quad \omega_i=0.6\sqrt{9.81k_i},\quad
\theta_i=k_i\,d_i\cdot q-\omega_i t+\phi_i
$$

O fator 0.6 é uma escala artística comum de tempo. A dispersão relativa é preservada: componentes longos propagam-se mais rápido que os curtos. A posição da partícula é:

$$
P_{xz}=q-\sum_i H_i d_i\sin\theta_i,\qquad
P_y=\sum_i A_i\cos\theta_i
$$

Isso gera deslocamento horizontal e vertical, com partículas se aproximando nas cristas e se afastando nos vales. As componentes interferem entre si, produzindo o movimento do campo oceânico inteiro. `wavelength` escala os comprimentos; `waveHeight` escala as amplitudes; `windAngle` gira as direções; `speed` escala o tempo; `seed` muda fases e a distribuição determinística.

`H_i` é a amplitude da órbita horizontal, calculada por componente. Com `S=min(0.90,1.05 × choppiness) × min(1,waveHeight)`, usamos `H_i = S × (A_i / sum(A)) / k_i`. Se a altura for zero, todas as órbitas são zero. Isso distribui o orçamento de compressão entre escalas e garante `sum(k_i H_i) <= 0.90`, evitando loops na superfície. Em alturas acima de 1 a compressão lateral satura, embora a altura vertical continue crescendo. As amplitudes das bandas têm uma escala artística comum de 0.72.

## Cristas, pontos e profundidade

As tangentes são derivadas analiticamente. O produto vetorial dá a normal, usada para reflexos e brilho dependentes da inclinação. A compressão é obtida pelo determinante do Jacobiano horizontal e realça a espuma nas cristas. Não desenhamos curvas de nível sobre a água. A espuma é um realce procedural instantâneo; não é uma simulação acumulativa de bolhas.

A névoa atenua a distância. Na versão 0.4, a profundidade dos pontos é uma progressão geométrica: `z = near × (far/near)^v`, com `v` estratificado. A distribuição reserva amostras tanto para o primeiro plano quanto para o horizonte. Uma margem lateral depende das órbitas e do parallax, para que o deslocamento não exponha uma borda lateral do campo. Uma transição suave esconde o limite distante finito.

Nos fundos escuros opacos, os fragmentos premultiplicados acumulam luz com `ONE, ONE`; regiões de concentração projetada podem ficar brilhantes sem precisar pintar toda a face de uma onda de branco. Fundos claros e transparentes usam `ONE, ONE_MINUS_SRC_ALPHA`. A projeção tem perspectiva, mas os pontos não testam nem escrevem profundidade. Não existe malha opaca auxiliar ou depth prepass. Essa escolha representa água em partículas translúcidas; não pretende ocultação exata de uma superfície sólida.

## O que roda na CPU e na GPU

| Trabalho | Onde / quando |
| --- | --- |
| Criar posições de repouso | CPU, ao montar e ao mudar contagem/seed |
| Preparar espectro e direções | CPU, ao mudar configuração |
| Atualizar as oito fases | CPU, por quadro desenhado: array de 128 bytes |
| Mover partículas, calcular normais, brilho e espuma | Vertex shader, GPU |
| Desenhar os pontos | Um `drawArrays(POINTS)` por quadro |
| Halo de cada partícula | Fragment shader, sem render target extra/bloom |
| Interação e círculos | Shader; ramos inativos são pulados |
| Atualização de props no Native | Ponte apenas quando as props mudam, nunca por partícula/quadro |

Não há loop JavaScript por partícula, mudança de estado React por quadro, texturas, vídeos, fontes ou assets remotos. As direções são normalizadas na CPU para evitar normalizações repetidas por partícula. Uniforms estáticos não são reenviados em cada quadro.

## Orçamento padrão para sites

`maxFps=30` limita os desenhos. O agendamento usa `requestAnimationFrame` e pula quadros que chegam antes do intervalo. O relógio do oceano não depende da quantidade de quadros: aumentar o limite não acelera as ondas. O limite é um teto, não garantia de FPS.

Com `adaptiveQuality=true`:

$$
B=\min(C,\max(2000,\operatorname{round}(0.75WH))),\qquad
N=\operatorname{round}(B\,\text{density})
$$

`W,H` são o tamanho do componente em pixels CSS. `C=100000` para `W<768`, e `C=340000` caso contrário. Em tamanho zero a contagem é zero. A adaptação usa o tamanho da área, não tenta adivinhar a potência exata da GPU e não oscila automaticamente a qualidade a partir de FPS. O teto desktop aumentou em relação à 0.3; essa troca prioriza detalhe. `density=0.6` é um perfil de menor custo.

| Exemplo | density | Partículas |
| --- | --- | --- |
| Desktop 1920 × 1080 | 1 | 340.000 |
| Área 1000 × 500 | 1 | 340.000 |
| Desktop 1920 × 1080 econômico | 0.6 | 204.000 |
| Mobile 390 × 844 | 1 | 100.000 |
| Mobile 390 × 844 | 0.5 | 50.000 |
| Contagem fixa, adaptiveQuality=false | 1 | 340.000 |

O DPR é um limite independente de resolução. O padrão 1.5 controla a área do framebuffer; `dpr={1}` reduz esse custo em dispositivos com pixel ratio maior que 1. Pontos maiores também aumentam o trabalho de preenchimento, então prefira os tamanhos padrão antes de elevar densidade e brilho.

O loop para quando a área sai da tela, a aba fica oculta, o tamanho é zero, `paused=true`, `speed=0` ou o sistema pede movimento reduzido. No Native, o estado do aplicativo também pausa a animação. Na retomada, o relógio não tenta recuperar todo o tempo que ficou parado. As interações só envelhecem quando a animação está avançando.

## Configuração do portfólio

Use o exemplo `examples/next/background.tsx`. Ele mantém a aparência padrão e usa `eventSource="window"`. Coloque o componente logo após abrir o `body`, com o restante do conteúdo acima. O `body` deve estabelecer um contexto de empilhamento, por exemplo com `position: relative` e `isolation: isolate` (Tailwind: `relative isolate`). O fundo é passivo (`pointer-events: none`) para não bloquear links, mas o renderer recebe os eventos globais da janela dentro dos limites do componente. Se quiser desligar as reações, passe `interactive={false} clickRipples={false}`.

`parallax=0` mantém a câmera fixa sem desligar a elevação; `swell=0` remove a elevação local sem remover o parallax; `clickRipples=false` limpa e desabilita anéis. As ondas de base não dependem do ponteiro. Com `eventSource="container"`, que é o padrão, os eventos são locais à área do componente. Na WebView, ambos os modos estão limitados ao documento da WebView.

Não coloque um overlay escuro ou `opacity` reduzida sobre o oceano se o objetivo é preservar o contraste do padrão. `backgroundColor` controla o fundo; `colors` controla a água e as cristas. Alterações em uma prop são intencionais e substituem apenas aquele padrão.

## Verificação e limites

Os testes matemáticos verificam dispersão, retorno de órbita, relevo do oceano padrão, tangentes por diferenças finitas, Jacobiano positivo e orçamento. O teste de navegador compila/renderiza GLSL de verdade, verifica contagem, atualizações de props, pausa, resize, limite de FPS, movimento sem props, entrada global através de conteúdo sobreposto, opções independentes de interação e o runtime usado pela WebView. A revisão determinística inspeciona cinco momentos da animação. O ambiente usa Chromium com renderização por software; não permite concluir desempenho de uma GPU real. O adaptador Native deve ser validado em Android/iOS nos aparelhos de destino.

Referência teórica: [Mark Finch, Effective Water Simulation from Physical Models, GPU Gems / NVIDIA](https://developer.nvidia.com/gpugems/gpugems/part-i-natural-effects/chapter-1-effective-water-simulation-physical-models). O código GLSL e TypeScript deste pacote é próprio, sob MIT.
