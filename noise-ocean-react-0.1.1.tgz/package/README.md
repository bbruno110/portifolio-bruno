# Noise Ocean React

Um oceano procedural de partículas ou linhas para usar como background em sites React. Escrito em TypeScript, com WebGL e fallback automático em Canvas 2D, configurável por props. Inclui playground e documentação em português no navegador.

**O movimento combina ondas direcionais, deslocamento horizontal das cristas e ruído suave que evolui no tempo.** A superfície muda de forma continuamente, com ondas se cruzando em direções e escalas diferentes.

## O que vem no projeto

- Componente `NoiseOcean`, com export nomeado e default.
- Tipos TypeScript e quatro presets: midnight, neon, arctic e ember.
- Partículas, linhas ou os dois juntos.
- Cores, fundo, amplitude, comprimento, direção, ruído, câmera e névoa configuráveis.
- Parallax, elevação sob o ponteiro e ondas ao clicar/tocar, todos opcionais.
- Limites de FPS e DPR; qualidade adaptativa; pausa fora da tela e em abas ocultas.
- Preferência de movimento reduzido respeitada por padrão.
- Playground responsivo com controles, código copiável e referência de todas as props.
- Build ESM com declarações `.d.ts`, exemplos e testes.

O componente não depende de Three.js, imagens, texturas, Tailwind ou folhas de estilo. React é uma peer dependency. O projeto inclui React DOM e Vite para desenvolver a demonstração.

## Requisitos

- Para desenvolver este repositório: Node.js **22.12 ou superior** e npm.
- Para consumir a biblioteca: React **18.2 ou 19** e navegador moderno com Canvas 2D e requestAnimationFrame. WebGL 1 é usado quando disponível. ResizeObserver é opcional.
- React para web. React Native nativo precisaria de outro renderer.
- Com `renderer="auto"` (padrão), falhas de WebGL ativam um oceano mais simples em Canvas 2D. Se nenhum renderer funcionar, o fundo CSS permanece. `onError` recebe o erro original.

## Começar pelo playground

```bash
npm install
npm run dev
```

Abra a URL indicada pelo Vite, normalmente `http://localhost:5173`. O frontend contém a demonstração e a documentação. O código em **Código** ou **Copiar componente** acompanha os valores atuais dos controles.

Use **Ajustes avançados** para câmera, direção, seed, detalhes do ruído e performance.

Para gerar uma versão independente, execute `npm run build:standalone` e abra `playground.html` no navegador. JavaScript e CSS ficam incorporados no arquivo, sem CDN ou fontes externas. O botão de copiar depende das permissões da área de transferência; se o navegador negar, selecione o código manualmente.

## Usar em outros projetos

O código é um repositório pronto para empacotar; não pressupõe que o nome `noise-ocean-react` já esteja publicado no npm.

### Opção A: instalar um pacote local

Na pasta deste repositório:

```bash
npm install
npm pack
```

O hook `prepack` compila e valida a biblioteca automaticamente. Ele gera `noise-ocean-react-0.1.1.tgz`. Copie esse arquivo para o outro projeto e instale:

```bash
npm install ./noise-ocean-react-0.1.1.tgz
```

Depois importe normalmente:

```tsx
import { NoiseOcean } from 'noise-ocean-react';
import type { NoiseOceanProps, OceanOptions } from 'noise-ocean-react';
```

Atualizações do código exigem gerar e instalar novamente o pacote. Para releases, aumente também a versão em `package.json`.

### Opção B: copiar o código fonte

Copie toda a pasta `src/` para, por exemplo, `src/components/noise-ocean/` no seu projeto. Preserve os arquivos auxiliares, pois o componente importa o engine, os shaders, os tipos e as opções.

```tsx
import { NoiseOcean } from './components/noise-ocean';
```

Nenhum CSS do playground é necessário.

### Opção C: dependência de uma pasta vizinha

Primeiro execute `npm install` e `npm run build` neste repositório. No outro projeto:

```bash
npm install ../noise-ocean-react
```

Esta opção depende de a pasta existir no ambiente de desenvolvimento/build. Use o `.tgz` ou um registro de pacotes para distribuir de forma independente.

## Exemplo: background de uma seção

```tsx
import { NoiseOcean } from 'noise-ocean-react';

export function Hero() {
  return (
    <section
      style={{
        position: 'relative',
        isolation: 'isolate',
        minHeight: '100svh',
        color: '#f5f5f5',
      }}
    >
      <NoiseOcean
        preset="neon"
        waveHeight={1.3}
        wavelength={1.1}
        speed={0.5}
      />

      <main style={{ position: 'relative', zIndex: 1, padding: '5rem 2rem' }}>
        <h1>Bruno Oliveira Santos</h1>
        <p>Full Stack / Back-end</p>
        <a href="/projetos">Ver projetos</a>
      </main>
    </section>
  );
}
```

O wrapper do oceano usa `inset: 0`, posição absoluta e `zIndex: 0`. O contêiner deve ser posicionado e ter altura. `isolation: isolate` organiza as camadas. O conteúdo acima usa `position: relative; z-index: 1`.

O componente é decorativo: usa `aria-hidden` e `pointer-events: none`. Links, botões e rolagem continuam disponíveis. As interações opcionais usam eventos de ponteiro passivos observados na janela e limitam seus efeitos aos limites visuais do componente. Cliques em conteúdo sobreposto também podem criar ondulações quando `clickRipples` está ativo.

## Next.js / fundo fixo

O bundle preserva `'use client'`. O acesso ao navegador começa dentro de um efeito, após a montagem; a renderização no servidor não acessa `window`, `document` ou WebGL.

Crie um wrapper client se usar callbacks:

```tsx
'use client';

import { NoiseOcean } from 'noise-ocean-react';

export function SiteBackground() {
  return (
    <NoiseOcean
      position="fixed"
      preset="neon"
      density={0.75}
      maxFps={30}
      dpr={1.25}
      onError={(error) => console.warn(error.message)}
    />
  );
}
```

Monte uma vez no layout:

```tsx
<div style={{ isolation: 'isolate', minHeight: '100svh' }}>
  <SiteBackground />
  <div style={{ position: 'relative', zIndex: 1 }}>{children}</div>
</div>
```

Evite ancestrais com `transform`, `filter` ou `perspective` ao usar `fixed`, pois eles podem mudar a referência de posicionamento. Não é necessário desativar SSR para usar o componente. Um Server Component pode passar props serializáveis; callbacks precisam ser definidos em um componente client.

## Presets e prioridade

```tsx
<NoiseOcean preset="midnight" />
<NoiseOcean preset="neon" />
<NoiseOcean preset="arctic" />
<NoiseOcean preset="ember" />
```

| Preset | Visual |
| --- | --- |
| midnight | Azul claro em fundo azul muito escuro |
| neon | Verde neon em fundo quase preto |
| arctic | Azul sobre fundo claro, com ondas suaves |
| ember | Laranja e cristas quentes, com ondas mais marcadas |

A resolução segue **padrões → preset → props explícitas**. Uma prop `undefined` mantém o valor anterior dessa cadeia. Exemplo:

```tsx
// Mantém as outras opções do preset, mas usa partículas brancas.
<NoiseOcean preset="neon" color="#ffffff" secondaryColor="#ffffff" />

// Mostra o fundo do seu contêiner através do oceano.
<NoiseOcean backgroundColor="transparent" color="#b6ff3b" />
```

Use cores CSS literais em `color` e `secondaryColor`, por exemplo `#b6ff3b`, `rgb(182,255,59)` ou `hsl(83,100%,62%)`. A transparência das partículas é controlada por `opacity`; o alpha de uma cor CSS não é usado como opacidade adicional. Variáveis CSS como `var(--accent)` não são resolvidas para as cores do shader: passe a cor resolvida como prop. `backgroundColor` é aplicado diretamente ao CSS e aceita `transparent` e variáveis CSS.

## Referência completa de props

Os valores abaixo são os padrões base, antes de aplicar um preset. Números fora das faixas são limitados; `NaN` e infinitos usam o padrão base. Todas as opções podem mudar após a montagem sem recriar o contexto WebGL.

<!-- PROPS:START -->
| Prop | Tipo | Padrão | Faixa | Descrição |
| --- | --- | --- | --- | --- |
| `renderer` | `'auto' \| 'webgl' \| 'canvas2d'` | `auto` | — | Auto tenta WebGL e usa Canvas 2D se a inicialização falhar ou o contexto for perdido. Canvas 2D tem menos detalhes. |
| `color` | `string` | `#7dd3fc` | — | Cor principal das partículas/linhas. Cor CSS literal, como hex, rgb() ou hsl(). |
| `secondaryColor` | `string` | `#e0f2fe` | — | Segunda cor, misturada nas cristas. Use a mesma cor para um visual monocromático. |
| `backgroundColor` | `string` | `#060b14` | — | Cor CSS do fundo. Aceita transparent para mostrar o fundo do contêiner. |
| `opacity` | `number` | `0.8` | 0–1 | Opacidade do oceano, sem alterar o fundo. |
| `mode` | `'points' \| 'lines' \| 'hybrid'` | `points` | — | Partículas, grade de linhas ou combinação dos dois. |
| `density` | `number` | `1` | 0.35–2 | Densidade da malha nos dois eixos. O custo cresce aproximadamente com o quadrado do valor. |
| `particleSize` | `number` | `2.2` | 0.5–6 | Tamanho base dos pontos em pixels CSS; a perspectiva também afeta o tamanho. |
| `waveHeight` | `number` | `1.2` | 0–4 | Amplitude das ondas e do ruído, em unidades da cena. |
| `wavelength` | `number` | `1` | 0.25–3 | Comprimento relativo das ondas. Maior = ondas mais largas. |
| `choppiness` | `number` | `0.55` | 0–1 | Deslocamento horizontal das cristas, que dá a sensação de rolamento. |
| `speed` | `number` | `0.65` | 0–3 | Velocidade do campo de ondas. Zero congela as ondas; interação pode continuar. |
| `windAngle` | `number` | `0.35` | -3.14–3.14 | Direção principal das ondas em radianos. |
| `noiseScale` | `number` | `0.16` | 0.02–0.6 | Frequência espacial do ruído. Maior = detalhes menores. |
| `noiseStrength` | `number` | `0.6` | 0–2 | Influência do ruído sobre as ondas direcionais. |
| `seed` | `number` | `7` | 0–10000 | Semente do ruído. Repete a configuração inicial no mesmo ambiente gráfico. |
| `cameraHeight` | `number` | `4.5` | 1–12 | Altura da câmera acima do plano da água. |
| `cameraTilt` | `number` | `0.19` | 0.02–0.65 | Inclinação da câmera para baixo em radianos. |
| `perspective` | `number` | `55` | 30–90 | Campo de visão vertical em graus. |
| `fog` | `number` | `0.65` | 0–1 | Intensidade do desvanecimento com a distância. |
| `interactive` | `boolean` | `false` | — | Ativa parallax e elevação suave da água sob o ponteiro. |
| `parallax` | `number` | `0.35` | 0–2 | Intensidade do deslocamento da câmera. Depende de interactive. |
| `swell` | `number` | `0.7` | 0–3 | Altura da elevação causada pelo ponteiro. Depende de interactive. |
| `swellRadius` | `number` | `8` | 1–20 | Raio da influência do ponteiro em unidades da cena. |
| `clickRipples` | `boolean` | `false` | — | Ativa até quatro ondas de clique/toque. Funciona mesmo sem interactive. |
| `rippleStrength` | `number` | `0.8` | 0–3 | Amplitude das ondas de clique/toque. |
| `paused` | `boolean` | `false` | — | Pausa o tempo, as interações e o loop contínuo. Mantém o último quadro. |
| `maxFps` | `number` | `30` | 15–120 | Teto configurável de 15 a 120 FPS. Não força a tela ou o navegador a operar nessa taxa. |
| `dpr` | `number` | `1.25` | 0.5–2.5 | Teto do DPR, limitado também pelo buffer da GPU e por 4 milhões de pixels. Canvas 2D limita o DPR a 1.25. |
| `adaptiveQuality` | `boolean` | `true` | — | Reduz a densidade após 90 amostras de renderização lenta. Não aumenta automaticamente. |
| `respectReducedMotion` | `boolean` | `true` | — | Mostra quadro estático quando o sistema solicita movimento reduzido. |
| `preset` | `'midnight' \| 'neon' \| 'arctic' \| 'ember'` | `midnight` | — | Base visual. Props explícitas têm prioridade. |
| `position` | `'absolute' \| 'fixed'` | `absolute` | — | Preenche o contêiner posicionado ou a viewport. |
| `zIndex` | `number` | `0` | — | Camada CSS do wrapper. Coloque o conteúdo em uma camada superior. |
| `className` | `string` | `—` | — | Classe aplicada ao wrapper externo. |
| `style` | `CSSProperties` | `—` | — | Estilos inline do wrapper; pointerEvents permanece none. |
| `onError` | `(error: Error) => void` | `—` | — | Notifica falhas de inicialização ou perda de contexto, inclusive quando auto ativa o fallback. Consulte data-ocean-renderer no wrapper para ver o renderer escolhido. |
<!-- PROPS:END -->

`windAngle` e `cameraTilt` usam **radianos**; `perspective` usa **graus**. Alturas, comprimentos e raios são unidades relativas da cena, não medidas físicas. O tamanho dos pontos é limitado também pela implementação WebGL do dispositivo. Linhas usam a espessura padrão de 1 pixel do WebGL; `particleSize` afeta apenas os pontos.

## Ajustar o movimento

### Telas de 90 Hz e 120 Hz

```tsx
<NoiseOcean
  preset="neon"
  maxFps={120}
  density={0.75}
  dpr={1}
  adaptiveQuality
/>
```

`maxFps` aceita números de **15 a 120**. Use 30, 60, 90 ou 120 no seletor do playground; o ajuste avançado aceita os valores intermediários. O limitador preserva os intervalos fracionários: configurar 90 FPS em uma tela de 120 Hz não reduz a animação automaticamente para 60 FPS.

O valor é um teto. Uma tela de 120 Hz pode receber apenas 60 callbacks por segundo do navegador, dependendo de configurações de energia, navegador e sistema. A prop não consegue forçar uma taxa maior do que a disponível. A velocidade das ondas usa tempo decorrido e não acelera quando você aumenta o FPS. 120 FPS também exige mais processamento e energia.

### Compatibilidade no celular e diagnóstico

O padrão `renderer="auto"` tenta WebGL e muda para Canvas 2D se houver falha na criação/compilação dos shaders ou perda do contexto. Há dois canvases separados porque um canvas que criou contexto WebGL não pode depois criar um contexto 2D. Somente o renderer escolhido mantém um loop de animação.

Para testar o caminho sem WebGL no próprio site:

```tsx
<NoiseOcean
  renderer="canvas2d"
  maxFps={60}
  density={0.65}
  dpr={1}
/>
```

Para registrar a falha original mantendo o fallback automático:

```tsx
<NoiseOcean
  renderer="auto"
  onError={(error) => console.warn('[NoiseOcean]', error.message)}
/>
```

No Next.js, defina esse callback em um wrapper com `'use client'`. O atributo `data-ocean-renderer` no wrapper informa `webgl` ou `canvas2d`, o renderer escolhido. `onError` também pode ser chamado quando a recuperação em Canvas 2D funciona; o callback não significa necessariamente que o fundo ficou vazio.

Canvas 2D usa uma malha menor, duas oitavas de ruído e cores agrupadas, com menos detalhe que o WebGL. Preserva ondas, perspectiva, cores, modos, pausa e interações. O DPR é limitado a 1,25 nesse renderer. Em ambos, o buffer tem um orçamento de 4 milhões de pixels; o WebGL também respeita os limites consultados na GPU. Esses limites reduzem resolução interna sem mudar o tamanho CSS.

Se ambos os renderers ficarem vazios, verifique se o pai realmente tem altura **no layout mobile**, se outro elemento cobre o oceano, e os erros de `onError`. Para testar seu servidor de desenvolvimento pelo celular na mesma rede, rode `npm run dev -- --host 0.0.0.0` e abra `http://IP_DO_PC:5173` no celular. `localhost` no celular aponta para o próprio celular.

ResizeObserver ausente não interrompe a montagem; resize, orientação, viewport visual e retorno à página atualizam o canvas. MediaQueryList antigo usa o listener compatível. Esses cuidados não substituem um teste no aparelho e no navegador finais.

### Ondas largas e suaves

```tsx
<NoiseOcean
  waveHeight={0.85}
  wavelength={1.6}
  choppiness={0.25}
  noiseStrength={0.35}
  speed={0.4}
/>
```

### Mar mais agitado

```tsx
<NoiseOcean
  waveHeight={1.8}
  wavelength={0.75}
  choppiness={0.85}
  noiseStrength={0.8}
  speed={0.9}
  windAngle={0.6}
/>
```

### Interação opcional

```tsx
<NoiseOcean
  interactive
  parallax={0.5}
  swell={0.7}
  swellRadius={8}
  clickRipples
  rippleStrength={0.8}
/>
```

`interactive` habilita parallax e elevação da água sob o ponteiro. Configure `parallax={0}` ou `swell={0}` para desativar apenas um desses efeitos. `clickRipples` funciona independentemente de `interactive`; no máximo quatro ondulações são mantidas. Toques usam o mesmo sistema sem cancelar o evento nem bloquear a rolagem. Eventos acima do horizonte são projetados no trecho distante da água.

### Controle externo de pausa

```tsx
const [paused, setPaused] = useState(false);

return (
  <section style={{ position: 'relative', minHeight: 500 }}>
    <NoiseOcean paused={paused} />
    <button
      style={{ position: 'relative', zIndex: 1 }}
      onClick={() => setPaused((value) => !value)}
    >
      {paused ? 'Retomar' : 'Pausar'}
    </button>
  </section>
);
```

Importe `useState` de `react` e use o trecho dentro de um componente. `paused` congela também as interações e suspende o loop contínuo; mudanças de props ou tamanho ainda redesenham o quadro estático. `speed={0}` congela apenas o campo de ondas; interações habilitadas podem continuar animando.

## Performance

A geometria é criada ao iniciar, ao mudar a densidade ou quando a qualidade adaptativa reduz a malha. O vertex shader calcula altura e deslocamento. O loop atualiza uniforms e desenha a mesma geometria; React não recebe atualizações a cada frame.

- Modo `points` ou `lines`: uma chamada de desenho por quadro.
- Modo `hybrid`: duas chamadas; mais preenchimento e sobreposição.
- Densidade base `1`: aproximadamente **25.200 vértices** (140 × 180).
- A densidade aumenta o número de amostras nos dois eixos, com teto de 62.500 vértices. Dobrar a densidade tem custo próximo de quatro vezes antes do teto.
- `dpr` limita o DPR real da tela; aumentar o DPR aumenta a quantidade de pixels nos dois eixos.
- `maxFps` limita os desenhos; um requestAnimationFrame leve pode continuar acompanhando a frequência da tela entre os desenhos.
- Abas ocultas e canvas fora da viewport suspendem o loop. O tempo não avança durante a suspensão.
- A preferência `prefers-reduced-motion: reduce` mantém um quadro estático por padrão.
- `powerPreference: 'low-power'` é uma indicação ao navegador, não uma garantia de qual GPU será usada.

| Uso | density | dpr | maxFps | mode |
| --- | --- | --- | --- | --- |
| Background em celular | 0.65–0.8 | 1–1.25 | 30 | points |
| Desktop equilibrado | 1 | 1.5 | 60 | points |
| Maior densidade visual | 1.4 | 1.5 | 60 | points ou hybrid |

Para começar em um site:

```tsx
<NoiseOcean
  preset="neon"
  density={0.75}
  dpr={1.25}
  maxFps={30}
  adaptiveQuality
/>
```

### Como a adaptação funciona

Quando `adaptiveQuality` está ativo no WebGL, o engine observa intervalos entre quadros desenhados. Depois de 90 amostras, se a média exceder 1,65 vez o maior entre o intervalo desejado e o menor intervalo de requestAnimationFrame observado, reduz a densidade efetiva nos dois eixos em 20%. Assim, pedir 120 FPS em um navegador que entrega 60 callbacks/s não implica, por si só, reduzir a qualidade. Pode repetir até um multiplicador de 0,45. No Canvas 2D, observa o tempo de execução de desenho na CPU: uma média acima de 75% do orçamento do FPS escolhido também reduz a densidade em 20% após 90 amostras. Mudar `density` ou `adaptiveQuality` restaura o multiplicador para 1 e reinicia a avaliação. A qualidade não aumenta automaticamente para evitar oscilações.

Esse mecanismo reage ao ritmo observado da página, incluindo outras cargas. Não mede tempo de GPU diretamente e não garante uma taxa de FPS. Os valores da tabela são sugestões para iniciar os testes, não benchmarks. Teste no celular e no layout final; duas ou mais instâncias custam mais que uma.

## Como o oceano é construído

1. Uma grade estática de amostras cobre um plano com maior concentração na parte próxima da câmera.
2. Três ondas senoidais com direções, frequências e velocidades diferentes se cruzam.
3. **Value noise interpolado**, combinado em fBm de quatro oitavas, acrescenta variação orgânica.
4. Uma deformação suave do domínio do ruído evolui no tempo.
5. O deslocamento horizontal das cristas cria a sensação de rolamento.
6. A projeção em perspectiva, as duas cores e o desvanecimento na distância criam profundidade.

É um oceano **visual e estilizado**. O ruído não é Perlin clássico. O deslocamento das cristas é inspirado em ondas paramétricas, sem ser uma implementação completa de Gerstner. Não há solver de fluidos, FFT, reflexos físicos, colisões ou interação com objetos. Isso mantém o escopo adequado a um background.

## Acessibilidade e ciclo de vida

O fundo não transmite informação essencial, fica oculto da árvore de acessibilidade e não recebe foco. A preferência por movimento reduzido é observada também quando muda durante a sessão. Evite desativar essa proteção em sites públicos; `respectReducedMotion={false}` existe para usos controlados.

O cleanup cancela o requestAnimationFrame, desconecta observers, remove eventos e libera programas/buffers WebGL. Funciona com o ciclo extra de montagem/cleanup do React Strict Mode. Perda de contexto suspende a renderização WebGL e dispara `onError`. No modo `auto`, o componente muda para Canvas 2D até ser remontado ou até a escolha de renderer mudar. No modo `webgl`, a restauração reconstrói os recursos quando o navegador disponibiliza o contexto novamente.

Se o navegador não conseguir iniciar WebGL, `renderer="auto"` ativa o fallback animado em Canvas 2D e `onError` recebe o `Error` original. Com `renderer="webgl"`, o fallback fica desativado. Sem nenhum renderer disponível, o fundo CSS permanece.

## Comandos

| Comando | Resultado |
| --- | --- |
| `npm run dev` | Playground e docs com atualização ao salvar |
| `npm run typecheck` | Verifica tipos do componente, demo e testes |
| `npm test` | Testes de opções, geometria, SSR e cobertura da documentação |
| `npm run test:browser` | Testes Chromium de animação, pausa, cores, interação, celular e fallback |
| `npm run build` | Gera biblioteca ESM, sourcemap e tipos em `dist/` |
| `npm run build:demo` | Gera site estático em `demo-dist/` |
| `npm run build:standalone` | Gera playground e docs em um único `playground.html` |
| `npm run preview` | Serve o site estático já gerado |
| `npm run docs:sync` | Atualiza a tabela de props do README a partir dos metadados do frontend |
| `npm pack` | Compila e gera o pacote `.tgz` |

Antes dos testes de navegador, instale o Chromium do Playwright:

```bash
npx playwright install chromium
npm run test:browser
```

Em Linux, se faltarem bibliotecas de sistema, use `npx playwright install --with-deps chromium`. Alternativamente, defina `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` com o caminho de um Chromium instalado. Os testes configuram renderização por software para verificar WebGL em ambientes sem GPU; isso não mede o desempenho do hardware do usuário.

## Estrutura

| Caminho | Responsabilidade |
| --- | --- |
| `src/NoiseOcean.tsx` | Wrapper React, estilos mínimos e efeitos |
| `src/engine.ts` | WebGL, geometria, eventos e ciclo de renderização |
| `src/canvas2d.ts` | Oceano simplificado para fallback sem WebGL |
| `src/runtime.ts` | Controle de FPS, dimensões e APIs opcionais de navegador |
| `src/shaders.ts` | Ruído e ondas executados na GPU |
| `src/options.ts` | Padrões, presets e limites numéricos |
| `src/types.ts` | API pública tipada |
| `src/index.ts` | Exports da biblioteca |
| `demo/` | Playground, documentação, estilos e metadados das props |
| `examples/` | Exemplos para integração |
| `tests/` | Testes unitários e de navegador |
| `scripts/sync-readme.ts` | Sincroniza a referência de props no README |
| `vite.lib.config.ts` | Build da biblioteca, externalizando React |
| `vite.config.ts` | Build do site de documentação |

## Subir para o Git

Crie um repositório vazio no GitHub ou no serviço que preferir. Dentro da pasta deste projeto:

```bash
git init
git add .
git commit -m "feat: add configurable noise ocean background"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

Troque a URL pelo seu repositório. O `.gitignore` exclui dependências, builds, pacotes gerados, resultados de testes e arquivos `.env`. O `package-lock.json` deve ser versionado. Não foram criados remotes nem publicados arquivos por estes comandos até você executá-los.

### Publicar a biblioteca no npm

Verifique a disponibilidade do nome no npm ou altere `name` para um escopo seu, como `@seu-usuario/noise-ocean-react`. Adicione `repository`, `homepage` e `bugs` ao `package.json` após definir o repositório. Se renomear o pacote, atualize os imports nos exemplos e na documentação.

```bash
npm run build
npm test
npm pack --dry-run
npm login
npm publish --access public
```

Confira a lista do dry-run antes de publicar. Somente `dist/`, README, LICENSE e metadados do pacote entram na distribuição. A publicação não é automática.

### Publicar o playground

Execute `npm ci && npm run build:demo` e publique a pasta `demo-dist/` no seu host estático. A configuração usa `base: './'`, permitindo servir a documentação também em subpastas. O componente não precisa desse site para funcionar.

## Dúvidas frequentes

**O oceano não aparece no celular.** Use `renderer="auto"` ou teste `renderer="canvas2d"`. Verifique se o pai tem altura no breakpoint mobile e `position: relative`, se o canvas está coberto por outro fundo e os erros de `onError`.

**As ondas estão paradas.** Confira `paused`, `speed`, a preferência de movimento reduzido do sistema e a visibilidade do componente.

**O movimento parece muito agitado.** Reduza `waveHeight`, `choppiness` e `noiseStrength`; aumente `wavelength`.

**Os pontos ficam espaçados demais.** Aumente `density` aos poucos, reduza `cameraHeight` ou ajuste `perspective`. `particleSize` aumenta o tamanho do ponto, sem acrescentar amostras.

**O celular esquenta ou perde fluidez.** Comece com `density={0.65}`, `dpr={1}` e `maxFps={30}`. Use `mode="points"` e mantenha `adaptiveQuality` ativo. Valide junto com o restante do site.

**Os cliques no conteúdo deixam de funcionar.** O componente força `pointer-events: none` no wrapper e no canvas. Verifique estilos e camadas de outros elementos sobrepostos.

**Posso garantir a mesma imagem em todas as GPUs?** Não. A seed estabiliza a entrada do ruído no mesmo ambiente; precisão de ponto flutuante e rasterização podem variar entre implementações WebGL.

## Referências técnicas

- [React: useEffect e cleanup](https://react.dev/reference/react/useEffect)
- [React: Strict Mode](https://react.dev/reference/react/StrictMode)
- [Vite: library mode](https://vite.dev/guide/build#library-mode)
- [MDN: WebGL](https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API)

## Licença

MIT — Copyright © 2026 Bruno Oliveira Santos. Você pode usar, modificar e distribuir, inclusive comercialmente, mantendo o aviso de licença. Veja [LICENSE](./LICENSE).
